
## 🎯 Sprint 0 التعديلات المُنجزة

- ✅ حقول `loinc_code` + `snomed_code` في جدول المنتجات
- ✅ FEFO triggers + `fefo_pick_batch()` + `execute_fefo_pick()`
- ✅ MKT calculation function
- ✅ `product_batches` table مع `remaining_shelf_pct`
- ✅ PEP 668: venv معزول لكل MCP server
- ✅ Intent Deconstruction في VoiceButton
- ✅ Draft Actions للموافقة على الإجراءات الصوتية الغامضة
- ✅ Pagination صارم (25 صف / 8000 حرف)
- ✅ `mcp_tool_registry` لتسجيل الأدوات الحساسة
- ✅ `approval_requests` table لـ Human-in-the-Loop
- ✅ **Report Drafts + Versioning + Digital Seal** (SHA-256 + QR)
- ✅ **Expiry Alert System** (4 مستويات + acknowledge + auto-scan)
- ✅ **Offline Queue** (local queue + auto-flush on reconnect)
- ✅ **Server Time Endpoint** (`get_server_time` — لا new Date())
- ✅ **computeStats** (FEFO-aware + server time only)
- ✅ **Rate Limiting** (per-tool enforcement في MCP)
- ✅ **Schema Validation** (CHECK constraints على تواريخ الدفعات)
- ✅ **Notification Preferences** (per-user, per-alert-type, per-channel)
- ✅ **quality_manager role** (صلاحية ختم/إلغاء التقارير)
