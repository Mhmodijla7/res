"""
Inventory MCP Server — FEFO-Enabled Cold Chain Inventory Management
===================================================================

يدعم:
- FEFO (First Expired, First Out) لاختيار الدفعات تلقائياً
- MKT (Mean Kinetic Temperature) لحسابات سلسلة التبريد
- Pagination صارمة لمنع تجاوز حدود Output Tokens
- Human-in-the-Loop للعمليات الحساسة
- Hash-Chain Audit Trail
- ★ Reports: Draft Mode + Versioning + Digital Seal
- ★ Expiry Alerts: Active notification system
- ★ Rate Limiting: Per-tool enforcement
- ★ Offline Queue: Connection resilience
- ★ Server Time: Consistent timezone handling
"""

import asyncio
import json
import hashlib
import logging
import time
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from typing import Any, Optional
from contextlib import asynccontextmanager

import asyncpg
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent, EmbeddedResource

logger = logging.getLogger("lab-inventory-mcp")

# =============================================================================
# Pagination & Output Control
# =============================================================================

MAX_ROWS_PER_RESPONSE = 25
MAX_CHARS_PER_FIELD = 500
MAX_TOTAL_RESPONSE_CHARS = 8000

def paginate_results(rows: list[dict], max_rows: int = MAX_ROWS_PER_RESPONSE) -> dict:
    """تقسيم النتائج + تنبيه LLM إن بقيت بيانات"""
    total = len(rows)
    page = rows[:max_rows]
    truncated = total > max_rows

    for row in page:
        for key, val in row.items():
            if isinstance(val, str) and len(val) > MAX_CHARS_PER_FIELD:
                row[key] = val[:MAX_CHARS_PER_FIELD] + "…[truncated]"
            elif isinstance(val, Decimal):
                row[key] = float(val)
            elif isinstance(val, datetime):
                row[key] = val.isoformat()

    result = {
        "data": page,
        "pagination": {
            "returned": len(page),
            "total": total,
            "truncated": truncated,
            "max_rows_per_call": max_rows,
            "instruction": "استخدم offset لإحضار المزيد" if truncated else "جميع النتائج مُعادة"
        }
    }

    serialized = json.dumps(result, ensure_ascii=False, default=str)
    if len(serialized) > MAX_TOTAL_RESPONSE_CHARS:
        result["data"] = result["data"][:10]
        result["pagination"]["returned"] = 10
        result["pagination"]["further_truncated_for_size"] = True
        result["pagination"]["reason"] = f"Response exceeded {MAX_TOTAL_RESPONSE_CHARS} chars"

    return result


def truncate_text(text: Optional[str], max_len: int = MAX_CHARS_PER_FIELD) -> Optional[str]:
    if text is None:
        return None
    if len(text) <= max_len:
        return text
    return text[:max_len] + "…[truncated]"


# =============================================================================
# Rate Limiting ★ Per-tool enforcement
# =============================================================================

_rate_limits: dict[str, list[float]] = defaultdict(list)

SENSITIVE_TOOL_LIMITS: dict[str, dict[str, int]] = {
    "adjust_stock": {"per_minute": 5, "per_hour": 50},
    "seal_report": {"per_minute": 3, "per_hour": 20},
    "void_report": {"per_minute": 2, "per_hour": 10},
    "fefo_pick": {"per_minute": 10, "per_hour": 200},
    "receive_batch": {"per_minute": 10, "per_hour": 200},
}

DEFAULT_LIMITS = {"per_minute": 30, "per_hour": 300}


def check_rate_limit(tool_name: str) -> tuple[bool, Optional[str]]:
    """
    فحص حد المعدل لكل أداة.
    يعيد (is_allowed, error_message)
    """
    now = time.time()
    window_minute = now - 60
    window_hour = now - 3600

    # تنظيف القديم
    _rate_limits[tool_name] = [t for t in _rate_limits[tool_name] if t > window_hour]

    limits = SENSITIVE_TOOL_LIMITS.get(tool_name, DEFAULT_LIMITS)

    recent_minute = sum(1 for t in _rate_limits[tool_name] if t > window_minute)
    recent_hour = len(_rate_limits[tool_name])

    if recent_minute >= limits["per_minute"]:
        return False, f"⚠️ تجاوز الحد: {limits['per_minute']} طلبات/دقيقة. حاول بعد لحظات."
    if recent_hour >= limits["per_hour"]:
        return False, f"⚠️ تجاوز الحد: {limits['per_hour']} طلبات/ساعة. حاول لاحقاً."

    _rate_limits[tool_name].append(now)
    return True, None


# =============================================================================
# Database Pool
# =============================================================================

_pool: Optional[asyncpg.Pool] = None

async def get_pool() -> asyncpg.Pool:
    global _pool
    if _pool is None:
        _pool = await asyncpg.create_pool(
            host="localhost",
            port=5432,
            database="lab_supply",
            user="mcp_inventory",
            password="CHANGE_ME_SECURELY",
            min_size=2,
            max_size=10,
            command_timeout=30,
        )
    return _pool


# =============================================================================
# Audit Logger
# =============================================================================

async def log_audit(
    pool: asyncpg.Pool,
    action: str,
    entity_type: str,
    entity_id: Optional[str],
    actor_id: str,
    actor_name: str,
    old_values: Optional[dict] = None,
    new_values: Optional[dict] = None,
    mcp_tool: str = "",
):
    """تسجيل كل عملية في سلسلة التدقيق"""
    async with pool.acquire() as conn:
        await conn.execute("""
            INSERT INTO audit_log (action, entity_type, entity_id,
                actor_type, actor_id, actor_name,
                old_values, new_values, mcp_server, mcp_tool)
            VALUES ($1::audit_action, $2, $3, $4, $5, $6, $7, $8, 'inventory', $9)
        """, action, entity_type, entity_id,
             'mcp_server', actor_id, actor_name,
             json.dumps(old_values, default=str) if old_values else None,
             json.dumps(new_values, default=str) if new_values else None,
             mcp_tool)


# =============================================================================
# FEFO Helper Functions
# =============================================================================

async def fefo_pick_batches(
    pool: asyncpg.Pool,
    product_id: str,
    quantity: int,
) -> dict:
    """FEFO: اختيار الدفعات تلقائياً حسب أقرب تاريخ انتهاء"""
    async with pool.acquire() as conn:
        rows = await conn.fetch("""
            SELECT * FROM fefo_pick_batch($1::uuid, $2)
        """, product_id, quantity)

        if not rows:
            return {
                "success": False,
                "error": f"لا توجد كمية كافية للمنتج {product_id}. المطلوب: {quantity}"
            }

        picks = []
        for r in rows:
            picks.append({
                "batch_id": str(r["batch_id"]),
                "batch_number": r["batch_number"],
                "expiry_date": r["expiry_date"].isoformat() if r["expiry_date"] else None,
                "available_qty": r["available_qty"],
                "pick_qty": r["pick_qty"],
                "remaining_shelf_pct": float(r["remaining_shelf"]) if r["remaining_shelf"] else None,
            })

        return {
            "success": True,
            "product_id": product_id,
            "requested_qty": quantity,
            "picks": picks,
            "fefo_note": "الدفعات مرتبة حسب FEFO — الأقرب انتهاءً يُستهلك أولاً"
        }


async def fefo_check_product_compliance(
    pool: asyncpg.Pool,
    product_id: str,
    quantity: int,
) -> dict:
    """فحص: هل تتوفر الكمية مع مراعاة FEFO + نسبة الصلاحية الدنيا؟"""
    async with pool.acquire() as conn:
        product = await conn.fetchrow("""
            SELECT id, name_ar, requires_fefo, min_remaining_shelf_pct,
                   stock_quantity, min_stock_level
            FROM products WHERE id = $1
        """, product_id)

        if not product:
            return {"compliant": False, "error": "المنتج غير موجود"}

        if product["stock_quantity"] < quantity:
            return {
                "compliant": False,
                "error": f"المخزون غير كافٍ. المتوفر: {product['stock_quantity']}, المطلوب: {quantity}"
            }

        if not product["requires_fefo"]:
            return {"compliant": True, "fefo_applied": False}

        available = await conn.fetch("""
            SELECT pb.id, pb.batch_number, pb.expiry_date,
                   pb.current_quantity, pb.remaining_shelf_pct
            FROM product_batches pb
            WHERE pb.product_id = $1
              AND pb.current_quantity > 0
              AND pb.is_quarantine = false
              AND pb.is_recalled = false
              AND pb.expiry_date > CURRENT_DATE
              AND pb.remaining_shelf_pct > $2
            ORDER BY pb.expiry_date ASC
        """, product_id, float(product["min_remaining_shelf_pct"]))

        total_available = sum(r["current_quantity"] for r in available)

        if total_available < quantity:
            return {
                "compliant": False,
                "error": f"الكمية المتاحة بصلاحية كافية: {total_available}, المطلوب: {quantity}",
                "suggestion": "قد تحتاج لقبول دفعات بصلاحية أقل أو طلب كمية من المورد",
                "available_batches": len(available),
            }

        return {
            "compliant": True,
            "fefo_applied": True,
            "available_with_good_shelf": total_available,
            "batches_available": len(available),
        }


async def calculate_mkt_for_sensor(
    pool: asyncpg.Pool,
    sensor_id: str,
    hours_back: int = 24,
) -> dict:
    """حساب MKT لمستشعر محدد"""
    async with pool.acquire() as conn:
        end_time = datetime.now(timezone.utc)
        start_time = end_time - timedelta(hours=hours_back)

        row = await conn.fetchrow("""
            SELECT * FROM calculate_mkt($1, $2, $3)
        """, sensor_id, start_time, end_time)

        if row is None or row["mkt_value_c"] is None:
            return {
                "sensor_id": sensor_id,
                "status": "no_data",
                "message": "لا توجد قراءات كافية لحساب MKT"
            }

        zone_limits = await conn.fetchrow("""
            SELECT zone FROM cold_chain_readings
            WHERE sensor_id = $1 ORDER BY recorded_at DESC LIMIT 1
        """, sensor_id)

        zone = zone_limits["zone"] if zone_limits else "ambient"
        limits = {
            "ambient": (15.0, 25.0),
            "refrigerated": (2.0, 8.0),
            "frozen": (-25.0, -15.0),
            "deep_frozen": (-85.0, -75.0),
            "cryogenic": (-200.0, -190.0),
        }
        z_min, z_max = limits.get(zone, (0, 40))

        mkt_val = float(row["mkt_value_c"])
        is_compliant = z_min <= mkt_val <= z_max

        result = {
            "sensor_id": sensor_id,
            "zone": zone,
            "period_hours": hours_back,
            "mkt_value_c": round(mkt_val, 2),
            "min_temp_c": float(row["min_temp_c"]) if row["min_temp_c"] else None,
            "max_temp_c": float(row["max_temp_c"]) if row["max_temp_c"] else None,
            "avg_temp_c": round(float(row["avg_temp_c"]), 2) if row["avg_temp_c"] else None,
            "std_deviation": round(float(row["std_dev"]), 2) if row["std_dev"] else None,
            "num_readings": row["num_readings"],
            "excursion_count": row["excursion_count"],
            "zone_limits": {"min_c": z_min, "max_c": z_max},
            "is_compliant": is_compliant,
            "status": "compliant" if is_compliant else "EXCURSION_DETECTED",
        }

        if not is_compliant:
            result["warning"] = (
                f"⚠️ تجاوز سلسلة التبريد! MKT={mkt_val}°C "
                f"خارج النطاق [{z_min}, {z_max}]°C"
            )

        return result


# =============================================================================
# MCP Server Definition
# =============================================================================

server = Server("lab-inventory-mcp")

@server.list_tools()
async def list_tools() -> list[Tool]:
    return [
        # === Existing tools (unchanged) ===
        Tool(
            name="check_stock",
            description="التحقق من المخزون الحالي لمنتج معين أو لقائمة منتجات. يدعم Pagination.",
            inputSchema={
                "type": "object",
                "properties": {
                    "product_id": {"type": "string", "description": "UUID المنتج (اختياري)"},
                    "category_slug": {"type": "string", "description": "slug القسم (اختياري)"},
                    "low_stock_only": {"type": "boolean", "default": False},
                    "cold_chain_only": {"type": "boolean", "default": False},
                    "offset": {"type": "integer", "default": 0}
                }
            }
        ),
        Tool(
            name="fefo_suggest",
            description="اقتراح الدفعات حسب FEFO (الأقرب انتهاءً أولاً) لمنتج معين. لا ينفذ سحباً فعلياً.",
            inputSchema={
                "type": "object",
                "properties": {
                    "product_id": {"type": "string"},
                    "quantity": {"type": "integer"}
                },
                "required": ["product_id", "quantity"]
            }
        ),
        Tool(
            name="fefo_pick",
            description="تنفيذ سحب FEFO فعلي — يخصم الدفعات الأقرب انتهاءً من المخزون. ⚠️ إجراء حساس.",
            inputSchema={
                "type": "object",
                "properties": {
                    "product_id": {"type": "string"},
                    "quantity": {"type": "integer"},
                    "order_id": {"type": "string"},
                    "user_id": {"type": "string"}
                },
                "required": ["product_id", "quantity", "user_id"]
            }
        ),
        Tool(
            name="adjust_stock",
            description="تعديل كمية المخزون يدوياً. 🔒 إجراء حساس — يتطلب موافقة بشرية.",
            inputSchema={
                "type": "object",
                "properties": {
                    "product_id": {"type": "string"},
                    "batch_id": {"type": "string"},
                    "quantity_change": {"type": "integer"},
                    "reason": {"type": "string"},
                    "user_id": {"type": "string"}
                },
                "required": ["product_id", "quantity_change", "reason", "user_id"]
            }
        ),
        Tool(
            name="get_batch_details",
            description="تفاصيل دفعة محددة: الرقم، الصلاحية، الكمية، النسبة المتبقية.",
            inputSchema={
                "type": "object",
                "properties": {"batch_id": {"type": "string"}},
                "required": ["batch_id"]
            }
        ),
        Tool(
            name="list_expiring_batches",
            description="عرض الدفعات القريبة الانتهاء. يدعم تحديد عدد الأيام والمنطقة الحرارية.",
            inputSchema={
                "type": "object",
                "properties": {
                    "days_ahead": {"type": "integer", "default": 30},
                    "zone": {"type": "string", "enum": ["ambient", "refrigerated", "frozen", "deep_frozen", "cryogenic"]},
                    "offset": {"type": "integer", "default": 0}
                }
            }
        ),
        Tool(
            name="cold_chain_mkt",
            description="حساب MKT (Mean Kinetic Temperature) لمستشعر محدد.",
            inputSchema={
                "type": "object",
                "properties": {
                    "sensor_id": {"type": "string"},
                    "hours_back": {"type": "integer", "default": 24}
                },
                "required": ["sensor_id"]
            }
        ),
        Tool(
            name="cold_chain_status",
            description="عرض حالة جميع مستشعرات سلسلة التبريد + تنبيهات التجاوز.",
            inputSchema={
                "type": "object",
                "properties": {
                    "zone": {"type": "string", "enum": ["ambient", "refrigerated", "frozen", "deep_frozen", "cryogenic"]},
                    "alarms_only": {"type": "boolean", "default": False}
                }
            }
        ),
        Tool(
            name="get_inventory_report",
            description="تقرير مخزون شامل: إجمالي القيمة، الدفعات، المنتجات منخفضة المخزون.",
            inputSchema={
                "type": "object",
                "properties": {
                    "format": {"type": "string", "enum": ["summary", "detailed"], "default": "summary"}
                }
            }
        ),
        Tool(
            name="receive_batch",
            description="تسجيل دفعة جديدة عند الاستلام من المورد.",
            inputSchema={
                "type": "object",
                "properties": {
                    "product_id": {"type": "string"},
                    "batch_number": {"type": "string"},
                    "quantity": {"type": "integer"},
                    "expiry_date": {"type": "string", "format": "date", "description": "YYYY-MM-DD"},
                    "manufacturing_date": {"type": "string", "format": "date"},
                    "unit_cost": {"type": "number"},
                    "supplier_id": {"type": "string"},
                    "received_at_temp_c": {"type": "number"},
                    "user_id": {"type": "string"}
                },
                "required": ["product_id", "batch_number", "quantity", "expiry_date", "user_id"]
            }
        ),

        # === ★ NEW TOOLS ===
        Tool(
            name="get_server_time",
            description="الحصول على وقت السيرفر المُوحَّد (UTC). لا تعتمد على وقت الجهاز المحلي أبداً.",
            inputSchema={
                "type": "object",
                "properties": {}
            }
        ),
        Tool(
            name="compute_fefo_stats",
            description="حساب إحصائيات FEFO من السيرفر: المنتهي، قريب الانتهاء (15/30 يوم)، المُمتثل.",
            inputSchema={
                "type": "object",
                "properties": {}
            }
        ),
        Tool(
            name="check_expiry_alerts",
            description="عرض تنبيهات الصلاحية النشطة (غير مُعترف بها). يُحدّث التنبيهات تلقائياً قبل العرض.",
            inputSchema={
                "type": "object",
                "properties": {
                    "level": {
                        "type": "string",
                        "enum": ["info", "warning", "critical", "expired"],
                        "description": "تصفية حسب المستوى (اختياري)"
                    },
                    "offset": {"type": "integer", "default": 0}
                }
            }
        ),
        Tool(
            name="acknowledge_alert",
            description="الإقرار بتنبيه صلاحية + تسجيل الإجراء المتخَذ.",
            inputSchema={
                "type": "object",
                "properties": {
                    "alert_id": {"type": "string", "description": "UUID التنبيه"},
                    "action_taken": {
                        "type": "string",
                        "enum": ["disposed", "returned", "discounted", "consumed", "ignored"],
                        "description": "الإجراء المتخَذ"
                    },
                    "notes": {"type": "string", "description": "ملاحظات إضافية"},
                    "user_id": {"type": "string"}
                },
                "required": ["alert_id", "action_taken", "user_id"]
            }
        ),
        Tool(
            name="create_report_draft",
            description="إنشاء مسودة تقرير (Draft Mode). لا تُصدَّر نهائياً حتى تتم المراجعة البشرية.",
            inputSchema={
                "type": "object",
                "properties": {
                    "draft_type": {
                        "type": "string",
                        "enum": ["inventory_summary", "expiry_report", "cold_chain", "fefo_compliance", "custom"],
                        "description": "نوع التقرير"
                    },
                    "title": {"type": "string", "description": "عنوان التقرير"},
                    "parameters": {
                        "type": "object",
                        "description": "مرشحات: date_range, categories, zones",
                        "properties": {
                            "date_from": {"type": "string", "format": "date"},
                            "date_to": {"type": "string", "format": "date"},
                            "category_ids": {"type": "array", "items": {"type": "string"}},
                            "zones": {"type": "array", "items": {"type": "string"}}
                        }
                    },
                    "generated_by_ai": {"type": "boolean", "default": False},
                    "user_id": {"type": "string"}
                },
                "required": ["draft_type", "title", "user_id"]
            }
        ),
        Tool(
            name="seal_report",
            description="ختم التقرير رقمياً (SHA-256 + QR). 🔒 إجراء حساس — يتطلب صلاحية quality_manager.",
            inputSchema={
                "type": "object",
                "properties": {
                    "draft_id": {"type": "string", "description": "UUID المسودة المعتمدة"},
                    "user_id": {"type": "string"}
                },
                "required": ["draft_id", "user_id"]
            }
        ),
        Tool(
            name="get_report_history",
            description="عرض سجل التقارير: المسودات، المختومة، المُلغاة. يدعم Pagination.",
            inputSchema={
                "type": "object",
                "properties": {
                    "status": {
                        "type": "string",
                        "enum": ["draft", "under_review", "approved", "sealed", "voided", "all"],
                        "default": "all"
                    },
                    "report_type": {"type": "string"},
                    "offset": {"type": "integer", "default": 0}
                }
            }
        ),
        Tool(
            name="process_offline_queue",
            description="معالجة طابور الاتصال المقطوع. يعيد الإجراءات المعلقة للمعالجة.",
            inputSchema={
                "type": "object",
                "properties": {
                    "limit": {"type": "integer", "default": 10, "description": "عدد الإجراءات للمعالجة"}
                }
            }
        ),
    ]


# =============================================================================
# Tool Dispatcher
# =============================================================================

@server.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    # ★ Rate Limiting check
    allowed, limit_error = check_rate_limit(name)
    if not allowed:
        return [TextContent(
            type="text",
            text=json.dumps({"error": limit_error, "rate_limited": True}, ensure_ascii=False)
        )]

    pool = await get_pool()

    try:
        handler_map = {
            "check_stock": handle_check_stock,
            "fefo_suggest": handle_fefo_suggest,
            "fefo_pick": handle_fefo_pick,
            "adjust_stock": handle_adjust_stock,
            "get_batch_details": handle_get_batch_details,
            "list_expiring_batches": handle_list_expiring,
            "cold_chain_mkt": handle_cold_chain_mkt,
            "cold_chain_status": handle_cold_chain_status,
            "get_inventory_report": handle_inventory_report,
            "receive_batch": handle_receive_batch,
            # ★ New handlers
            "get_server_time": handle_get_server_time,
            "compute_fefo_stats": handle_compute_fefo_stats,
            "check_expiry_alerts": handle_check_expiry_alerts,
            "acknowledge_alert": handle_acknowledge_alert,
            "create_report_draft": handle_create_report_draft,
            "seal_report": handle_seal_report,
            "get_report_history": handle_get_report_history,
            "process_offline_queue": handle_process_offline_queue,
        }

        handler = handler_map.get(name)
        if handler:
            result = await handler(pool, arguments)
        else:
            result = {"error": f"أداة غير معروفة: {name}"}
    except Exception as e:
        logger.exception(f"Error in tool {name}")
        result = {"error": str(e)}

    return [TextContent(
        type="text",
        text=json.dumps(result, ensure_ascii=False, default=str)
    )]


# =============================================================================
# Existing Tool Handlers (unchanged)
# =============================================================================

async def handle_check_stock(pool: asyncpg.Pool, args: dict) -> dict:
    low_stock_only = args.get("low_stock_only", False)
    cold_chain_only = args.get("cold_chain_only", False)
    offset = args.get("offset", 0)
    product_id = args.get("product_id")
    category_slug = args.get("category_slug")

    async with pool.acquire() as conn:
        if product_id:
            row = await conn.fetchrow("""
                SELECT
                    p.id, p.sku, p.name_ar, p.name_en,
                    p.stock_quantity, p.reserved_quantity,
                    p.stock_quantity - p.reserved_quantity AS available,
                    p.min_stock_level, p.reorder_quantity,
                    p.unit_of_measure, p.storage_zone,
                    p.requires_cold_chain, p.requires_fefo,
                    p.unit_price,
                    c.name_ar AS category_name,
                    b.name AS brand_name
                FROM products p
                LEFT JOIN categories c ON p.category_id = c.id
                LEFT JOIN brands b ON p.brand_id = b.id
                WHERE p.id = $1
            """, product_id)

            if not row:
                return {"error": "المنتج غير موجود"}

            batches = await conn.fetch("""
                SELECT id, batch_number, expiry_date, current_quantity,
                       remaining_shelf_pct, storage_zone
                FROM product_batches
                WHERE product_id = $1 AND current_quantity > 0
                ORDER BY expiry_date ASC
            """, product_id)

            result = dict(row)
            result["batches"] = [dict(b) for b in batches]
            result["batch_count"] = len(batches)
            return result

        conditions = ["p.is_active = true"]
        params = []
        idx = 1

        if low_stock_only:
            conditions.append("p.stock_quantity <= p.min_stock_level")
        if cold_chain_only:
            conditions.append("p.requires_cold_chain = true")
        if category_slug:
            conditions.append(f"c.slug = ${idx}")
            params.append(category_slug)
            idx += 1

        where = " AND ".join(conditions)

        rows = await conn.fetch(f"""
            SELECT
                p.id, p.sku, p.name_ar, p.stock_quantity,
                p.min_stock_level, p.storage_zone, p.requires_fefo,
                c.name_ar AS category_name
            FROM products p
            LEFT JOIN categories c ON p.category_id = c.id
            WHERE {where}
            ORDER BY p.name_ar
            LIMIT {MAX_ROWS_PER_RESPONSE + 1} OFFSET $1
        """, offset, *params)

        total = await conn.fetchval(f"""
            SELECT COUNT(*) FROM products p
            LEFT JOIN categories c ON p.category_id = c.id
            WHERE {where}
        """, *params)

        rows_dict = [dict(r) for r in rows[:MAX_ROWS_PER_RESPONSE]]
        has_more = len(rows) > MAX_ROWS_PER_RESPONSE

        return paginate_results(rows_dict, MAX_ROWS_PER_RESPONSE) | {
            "pagination": {
                "returned": len(rows_dict),
                "total": total,
                "offset": offset,
                "has_more": has_more,
                "truncated": has_more,
            }
        }


async def handle_fefo_suggest(pool: asyncpg.Pool, args: dict) -> dict:
    product_id = args["product_id"]
    quantity = args["quantity"]
    compliance = await fefo_check_product_compliance(pool, product_id, quantity)
    if not compliance.get("compliant"):
        return compliance
    return await fefo_pick_batches(pool, product_id, quantity)


async def handle_fefo_pick(pool: asyncpg.Pool, args: dict) -> dict:
    product_id = args["product_id"]
    quantity = args["quantity"]
    user_id = args["user_id"]
    order_id = args.get("order_id")

    compliance = await fefo_check_product_compliance(pool, product_id, quantity)
    if not compliance.get("compliant"):
        return compliance

    async with pool.acquire() as conn:
        row = await conn.fetchrow("""
            SELECT execute_fefo_pick($1::uuid, $2, $3::uuid, $4, $5::uuid)
        """, product_id, quantity, user_id,
             "order" if order_id else "adjustment",
             order_id)

        result = json.loads(row[0]) if row[0] else {"error": "فشل التنفيذ"}

    if result.get("success"):
        product_name = await _get_product_name(pool, product_id)
        await log_audit(
            pool, "update", "product", product_id,
            "mcp:fefo_pick", "FEFO Auto-Pick",
            old_values={"action": "fefo_pick_pending"},
            new_values={"product": product_name, "quantity": quantity, "picked_batches": result.get("picked", [])},
            mcp_tool="fefo_pick"
        )

    return result


async def handle_adjust_stock(pool: asyncpg.Pool, args: dict) -> dict:
    product_id = args["product_id"]
    quantity_change = args["quantity_change"]
    reason = args["reason"]
    user_id = args["user_id"]
    batch_id = args.get("batch_id")

    async with pool.acquire() as conn:
        product = await conn.fetchrow("""
            SELECT name_ar, stock_quantity FROM products WHERE id = $1
        """, product_id)

        if not product:
            return {"error": "المنتج غير موجود"}

        requires_approval = abs(quantity_change) > 10 or quantity_change < 0

        if requires_approval:
            approval = await conn.fetchrow("""
                INSERT INTO approval_requests (
                    request_type, entity_type, entity_id,
                    requested_by, action_description, action_params, assigned_to
                ) VALUES (
                    'stock_adjustment', 'product', $1::uuid,
                    $2, $3, $4, (SELECT id FROM users WHERE id = $2)
                ) RETURNING id
            """, product_id,
                 f"mcp:user:{user_id}",
                 f"تعديل مخزون «{product['name_ar']}» بمقدار {quantity_change}. السبب: {reason}",
                 json.dumps({"product_id": product_id, "batch_id": batch_id, "quantity_change": quantity_change, "reason": reason}))

            await log_audit(
                pool, "update", "product", product_id,
                "mcp:adjust_stock", "Adjust Stock (Pending Approval)",
                new_values={"approval_id": str(approval["id"]), "quantity_change": quantity_change},
                mcp_tool="adjust_stock"
            )

            return {
                "status": "pending_approval",
                "approval_id": str(approval["id"]),
                "message": f"🔒 تم إنشاء طلب موافقة لتعديل مخزون «{product['name_ar']}» بمقدار {quantity_change}. الكمية الحالية: {product['stock_quantity']}.",
                "requires_human_action": True,
            }
        else:
            new_qty = product["stock_quantity"] + quantity_change
            await conn.execute("""
                UPDATE products SET stock_quantity = $1, updated_at = NOW() WHERE id = $2
            """, new_qty, product_id)

            await log_audit(
                pool, "update", "product", product_id,
                "mcp:adjust_stock", "Adjust Stock (Direct)",
                old_values={"stock_quantity": product["stock_quantity"]},
                new_values={"stock_quantity": new_qty, "change": quantity_change, "reason": reason},
                mcp_tool="adjust_stock"
            )

            return {
                "status": "completed",
                "product": product["name_ar"],
                "old_quantity": product["stock_quantity"],
                "new_quantity": new_qty,
                "change": quantity_change,
            }


async def handle_get_batch_details(pool: asyncpg.Pool, args: dict) -> dict:
    async with pool.acquire() as conn:
        row = await conn.fetchrow("""
            SELECT pb.*, p.name_ar AS product_name, p.sku,
                   p.storage_zone AS product_storage_zone, p.min_remaining_shelf_pct
            FROM product_batches pb
            JOIN products p ON pb.product_id = p.id
            WHERE pb.id = $1
        """, args["batch_id"])

        if not row:
            return {"error": "الدفعة غير موجودة"}

        result = dict(row)

        movements = await conn.fetch("""
            SELECT movement_type, quantity, created_at, notes
            FROM batch_movements WHERE batch_id = $1
            ORDER BY created_at DESC LIMIT 10
        """, args["batch_id"])

        result["recent_movements"] = [dict(m) for m in movements]
        return result


async def handle_list_expiring(pool: asyncpg.Pool, args: dict) -> dict:
    days = args.get("days_ahead", 30)
    zone = args.get("zone")
    offset = args.get("offset", 0)

    conditions = [
        "pb.current_quantity > 0",
        f"pb.expiry_date <= CURRENT_DATE + INTERVAL '{days} days'",
    ]
    params = []
    idx = 1

    if zone:
        conditions.append(f"pb.storage_zone = ${idx}")
        params.append(zone)
        idx += 1

    where = " AND ".join(conditions)

    async with pool.acquire() as conn:
        rows = await conn.fetch(f"""
            SELECT
                pb.id AS batch_id, pb.batch_number, pb.expiry_date,
                pb.current_quantity, pb.remaining_shelf_pct,
                p.sku, p.name_ar, p.name_en, p.min_remaining_shelf_pct,
                CASE
                    WHEN pb.expiry_date <= CURRENT_DATE THEN 'EXPIRED'
                    WHEN pb.remaining_shelf_pct <= p.min_remaining_shelf_pct THEN 'CRITICAL'
                    WHEN pb.expiry_date <= CURRENT_DATE + INTERVAL '7 days' THEN 'URGENT'
                    WHEN pb.expiry_date <= CURRENT_DATE + INTERVAL '30 days' THEN 'WARNING'
                    ELSE 'OK'
                END AS expiry_status
            FROM product_batches pb
            JOIN products p ON pb.product_id = p.id
            WHERE {where}
            ORDER BY pb.expiry_date ASC
            LIMIT {MAX_ROWS_PER_RESPONSE + 1} OFFSET ${idx}
        """, *params, offset)

        total = await conn.fetchval(f"""
            SELECT COUNT(*) FROM product_batches pb
            JOIN products p ON pb.product_id = p.id
            WHERE {where}
        """, *params)

        rows_dict = [dict(r) for r in rows[:MAX_ROWS_PER_RESPONSE]]
        return paginate_results(rows_dict, MAX_ROWS_PER_RESPONSE) | {
            "days_ahead": days, "zone": zone,
            "pagination": {"total": total, "offset": offset, "has_more": len(rows) > MAX_ROWS_PER_RESPONSE}
        }


async def handle_cold_chain_mkt(pool: asyncpg.Pool, args: dict) -> dict:
    return await calculate_mkt_for_sensor(pool, args["sensor_id"], args.get("hours_back", 24))


async def handle_cold_chain_status(pool: asyncpg.Pool, args: dict) -> dict:
    zone = args.get("zone")
    alarms_only = args.get("alarms_only", False)

    async with pool.acquire() as conn:
        conditions = []
        params = []
        idx = 1

        if zone:
            conditions.append(f"zone = ${idx}")
            params.append(zone)
            idx += 1
        if alarms_only:
            conditions.append("is_alarm = true")

        where = "WHERE " + " AND ".join(conditions) if conditions else ""

        rows = await conn.fetch(f"""
            SELECT DISTINCT ON (sensor_id)
                sensor_id, location, zone, temperature_c,
                humidity_pct, is_alarm, alarm_reason, recorded_at
            FROM cold_chain_readings {where}
            ORDER BY sensor_id, recorded_at DESC
            LIMIT {MAX_ROWS_PER_RESPONSE}
        """, *params)

        sensors = []
        for r in rows:
            sensor = dict(r)
            mkt = await calculate_mkt_for_sensor(pool, r["sensor_id"], 24)
            sensor["mkt_24h"] = mkt
            sensors.append(sensor)

        return paginate_results(sensors, MAX_ROWS_PER_RESPONSE)


async def handle_inventory_report(pool: asyncpg.Pool, args: dict) -> dict:
    fmt = args.get("format", "summary")

    async with pool.acquire() as conn:
        stats = await conn.fetchrow("""
            SELECT
                COUNT(*) AS total_products,
                SUM(stock_quantity) AS total_units,
                SUM(stock_quantity * unit_price) AS total_value,
                COUNT(*) FILTER (WHERE stock_quantity <= min_stock_level) AS low_stock_count,
                COUNT(*) FILTER (WHERE requires_cold_chain = true) AS cold_chain_products
            FROM products WHERE is_active = true
        """)

        expiring_30 = await conn.fetchval("""
            SELECT COUNT(*) FROM product_batches
            WHERE current_quantity > 0
              AND expiry_date <= CURRENT_DATE + INTERVAL '30 days'
              AND expiry_date > CURRENT_DATE
        """)

        expired = await conn.fetchval("""
            SELECT COUNT(*) FROM product_batches
            WHERE current_quantity > 0 AND expiry_date <= CURRENT_DATE
        """)

        result = {
            "summary": {
                "total_products": stats["total_products"],
                "total_units": stats["total_units"],
                "total_value_sar": float(stats["total_value"]) if stats["total_value"] else 0,
                "low_stock_count": stats["low_stock_count"],
                "cold_chain_products": stats["cold_chain_products"],
                "batches_expiring_30d": expiring_30,
                "batches_expired": expired,
            }
        }

        if fmt == "detailed":
            low_stock = await conn.fetch("""
                SELECT p.sku, p.name_ar, p.stock_quantity, p.min_stock_level
                FROM products p
                WHERE p.stock_quantity <= p.min_stock_level AND p.is_active = true
                ORDER BY (p.stock_quantity::float / NULLIF(p.min_stock_level, 0))
                LIMIT 15
            """)
            result["low_stock_items"] = [dict(r) for r in low_stock]

        return result


async def handle_receive_batch(pool: asyncpg.Pool, args: dict) -> dict:
    async with pool.acquire() as conn:
        async with conn.transaction():
            batch = await conn.fetchrow("""
                INSERT INTO product_batches (
                    product_id, batch_number, initial_quantity, current_quantity,
                    manufacturing_date, expiry_date, unit_cost, supplier_id,
                    received_at_temp_c, storage_zone
                ) VALUES (
                    $1, $2, $3, $3, $4, $5, $6, $7, $8,
                    (SELECT storage_zone FROM products WHERE id = $1)
                ) RETURNING id, batch_number, expiry_date, remaining_shelf_pct
            """,
                args["product_id"], args["batch_number"], args["quantity"],
                args.get("manufacturing_date"), args["expiry_date"],
                args.get("unit_cost"), args.get("supplier_id"),
                args.get("received_at_temp_c"))

            await conn.execute("""
                UPDATE products SET stock_quantity = stock_quantity + $1, updated_at = NOW()
                WHERE id = $2
            """, args["quantity"], args["product_id"])

            await conn.execute("""
                INSERT INTO batch_movements (
                    batch_id, product_id, movement_type, quantity,
                    reference_type, temperature_at_move, performed_by
                ) VALUES ($1, $2, 'receive', $3, 'purchase', $4, $5)
            """, batch["id"], args["product_id"], args["quantity"],
                 args.get("received_at_temp_c"), args.get("user_id"))

    await log_audit(
        pool, "create", "batch", str(batch["id"]),
        "mcp:receive_batch", "Receive Batch",
        new_values={"batch_number": args["batch_number"], "quantity": args["quantity"], "expiry_date": args["expiry_date"]},
        mcp_tool="receive_batch"
    )

    return {
        "status": "received",
        "batch_id": str(batch["id"]),
        "batch_number": batch["batch_number"],
        "expiry_date": batch["expiry_date"].isoformat(),
        "remaining_shelf_pct": float(batch["remaining_shelf_pct"]) if batch["remaining_shelf_pct"] else None,
        "quantity_added": args["quantity"],
        "fefo_note": "الدفعة ستُسحب تلقائياً عند اقتراب انتهاء صلاحيتها (FEFO)",
    }


# =============================================================================
# ★ NEW TOOL HANDLERS
# =============================================================================

async def handle_get_server_time(pool: asyncpg.Pool, args: dict) -> dict:
    """
    وقت السيرفر المُوحَّد.
    ★ لا تعتمد أبداً على new Date() في المتصفح — استخدم هذا دائماً.
    """
    async with pool.acquire() as conn:
        row = await conn.fetchrow("SELECT NOW() AS utc_now, CURRENT_DATE AS server_date")
        return {
            "utc": row["utc_now"].isoformat(),
            "server_date": row["server_date"].isoformat(),
            "unix_timestamp": row["utc_now"].timestamp(),
            "timezone": "UTC",
            "instruction": "استخدم هذا الوقت بدلاً من وقت الجهاز المحلي لحسابات FEFO والانتهاء"
        }


async def handle_compute_fefo_stats(pool: asyncpg.Pool, args: dict) -> dict:
    """
    ★ حساب إحصائيات FEFO من السيرفر (ليس من المتصفح).
    يضمن استخدام وقت السيرفر المُوحَّد.
    """
    async with pool.acquire() as conn:
        row = await conn.fetchrow("SELECT compute_fefo_stats()")
        stats = json.loads(row[0]) if row[0] else {}
        return stats


async def handle_check_expiry_alerts(pool: asyncpg.Pool, args: dict) -> dict:
    """
    ★ عرض تنبيهات الصلاحية النشطة.
    يُحدّث التنبيهات تلقائياً عبر create_expiry_alerts() قبل العرض.
    """
    level = args.get("level")
    offset = args.get("offset", 0)

    async with pool.acquire() as conn:
        # تحديث التنبيهات أولاً
        new_count = await conn.fetchval("SELECT create_expiry_alerts()")
        logger.info(f"Updated {new_count} expiry alerts")

        conditions = ["ea.acknowledged = false"]
        params = []
        idx = 1

        if level:
            conditions.append(f"ea.alert_level = ${idx}::expiry_alert_level")
            params.append(level)
            idx += 1

        where = " AND ".join(conditions)

        rows = await conn.fetch(f"""
            SELECT
                ea.id, ea.alert_level, ea.days_until_expiry,
                ea.batch_number, ea.current_quantity, ea.expiry_date,
                ea.acknowledged, ea.action_taken,
                p.sku, p.name_ar, p.name_en, p.storage_zone,
                c.name_ar AS category_name
            FROM expiry_alerts ea
            JOIN products p ON ea.product_id = p.id
            LEFT JOIN categories c ON p.category_id = c.id
            WHERE {where}
            ORDER BY ea.days_until_expiry ASC
            LIMIT {MAX_ROWS_PER_RESPONSE + 1} OFFSET ${idx}
        """, *params, offset)

        total = await conn.fetchval(f"""
            SELECT COUNT(*) FROM expiry_alerts ea WHERE {where}
        """, *params)

        # ملخص سريع
        summary = await conn.fetchrow("""
            SELECT
                COUNT(*) FILTER (WHERE alert_level = 'expired' AND acknowledged = false) AS expired,
                COUNT(*) FILTER (WHERE alert_level = 'critical' AND acknowledged = false) AS critical,
                COUNT(*) FILTER (WHERE alert_level = 'warning' AND acknowledged = false) AS warning,
                COUNT(*) FILTER (WHERE alert_level = 'info' AND acknowledged = false) AS info_count
            FROM expiry_alerts
        """)

        rows_dict = [dict(r) for r in rows[:MAX_ROWS_PER_RESPONSE]]
        return paginate_results(rows_dict, MAX_ROWS_PER_RESPONSE) | {
            "summary": {
                "expired": summary["expired"],
                "critical": summary["critical"],
                "warning": summary["warning"],
                "info": summary["info_count"],
            },
            "alerts_refreshed": new_count,
            "pagination": {"total": total, "offset": offset, "has_more": len(rows) > MAX_ROWS_PER_RESPONSE}
        }


async def handle_acknowledge_alert(pool: asyncpg.Pool, args: dict) -> dict:
    """★ الإقرار بتنبيه صلاحية"""
    alert_id = args["alert_id"]
    action_taken = args["action_taken"]
    user_id = args["user_id"]
    notes = args.get("notes", "")

    async with pool.acquire() as conn:
        alert = await conn.fetchrow("""
            SELECT ea.*, p.name_ar AS product_name
            FROM expiry_alerts ea
            JOIN products p ON ea.product_id = p.id
            WHERE ea.id = $1
        """, alert_id)

        if not alert:
            return {"error": "التنبيه غير موجود"}
        if alert["acknowledged"]:
            return {"error": "تم الإقرار بهذا التنبيه مسبقاً"}

        await conn.execute("""
            UPDATE expiry_alerts SET
                acknowledged = true,
                acknowledged_by = $1,
                acknowledged_at = NOW(),
                action_taken = $2
            WHERE id = $3
        """, user_id, action_taken, alert_id)

    await log_audit(
        pool, "update", "expiry_alert", alert_id,
        f"user:{user_id}", "Acknowledge Alert",
        old_values={"acknowledged": False},
        new_values={"acknowledged": True, "action_taken": action_taken, "notes": notes},
        mcp_tool="acknowledge_alert"
    )

    return {
        "status": "acknowledged",
        "alert_id": alert_id,
        "product": alert["product_name"],
        "batch": alert["batch_number"],
        "action_taken": action_taken,
    }


async def handle_create_report_draft(pool: asyncpg.Pool, args: dict) -> dict:
    """
    ★ إنشاء مسودة تقرير (Draft Mode).
    لا تُصدَّر نهائياً — تنتظر مراجعة بشرية.
    """
    draft_type = args["draft_type"]
    title = args["title"]
    user_id = args["user_id"]
    parameters = args.get("parameters", {})
    generated_by_ai = args.get("generated_by_ai", False)

    async with pool.acquire() as conn:
        # جمع بيانات المخزون (snapshot)
        snapshot = {}
        if draft_type in ("inventory_summary", "fefo_compliance"):
            stats = await conn.fetchrow("SELECT compute_fefo_stats()")
            snapshot["fefo_stats"] = json.loads(stats[0]) if stats[0] else {}

        if draft_type in ("inventory_summary", "expiry_report"):
            low_stock = await conn.fetch("""
                SELECT p.sku, p.name_ar, p.stock_quantity, p.min_stock_level
                FROM products p
                WHERE p.stock_quantity <= p.min_stock_level AND p.is_active = true
                ORDER BY p.stock_quantity ASC LIMIT 25
            """)
            snapshot["low_stock_items"] = [dict(r) for r in low_stock]

        if draft_type == "cold_chain":
            sensors = await conn.fetch("""
                SELECT DISTINCT ON (sensor_id)
                    sensor_id, location, zone, temperature_c, is_alarm
                FROM cold_chain_readings ORDER BY sensor_id, recorded_at DESC
            """)
            snapshot["cold_chain_status"] = [dict(s) for s in sensors]

        # حساب hash للمسودة
        content_str = json.dumps({
            "type": draft_type, "title": title,
            "parameters": parameters, "snapshot": snapshot
        }, default=str, ensure_ascii=False)
        hash_draft = hashlib.sha256(content_str.encode()).hexdigest()

        # إدراج المسودة
        draft = await conn.fetchrow("""
            INSERT INTO report_drafts (
                draft_type, title, parameters,
                inventory_snapshot, computed_stats,
                generated_by_ai, status, created_by, hash_draft
            ) VALUES ($1, $2, $3, $4, $5, $6, 'draft', $7, $8)
            RETURNING id, created_at
        """, draft_type, title,
             json.dumps(parameters, default=str),
             json.dumps(snapshot, default=str),
             json.dumps(snapshot.get("fefo_stats", {}), default=str),
             generated_by_ai, user_id, hash_draft)

    await log_audit(
        pool, "create", "report_draft", str(draft["id"]),
        f"user:{user_id}", "Create Report Draft",
        new_values={"draft_type": draft_type, "title": title, "generated_by_ai": generated_by_ai},
        mcp_tool="create_report_draft"
    )

    return {
        "status": "draft_created",
        "draft_id": str(draft["id"]),
        "draft_type": draft_type,
        "title": title,
        "hash_draft": hash_draft,
        "snapshot_summary": {
            "has_fefo_stats": "fefo_stats" in snapshot,
            "low_stock_count": len(snapshot.get("low_stock_items", [])),
            "cold_chain_sensors": len(snapshot.get("cold_chain_status", [])),
        },
        "next_step": "يحتاج مراجعة بشرية قبل الختم. استخدم seal_report بعد الموافقة.",
        "created_at": draft["created_at"].isoformat(),
    }


async def handle_seal_report(pool: asyncpg.Pool, args: dict) -> dict:
    """
    ★ ختم التقرير رقمياً.
    🔒 إجراء حساس — يُنشئ digital_seal (SHA-256) + QR data.
    """
    draft_id = args["draft_id"]
    user_id = args["user_id"]

    async with pool.acquire() as conn:
        # التحقق من المسودة
        draft = await conn.fetchrow("""
            SELECT * FROM report_drafts WHERE id = $1
        """, draft_id)

        if not draft:
            return {"error": "المسودة غير موجودة"}

        if draft["status"] not in ("draft", "approved"):
            return {"error": f"لا يمكن ختم مسودة بحالة '{draft['status']}'. يجب أن تكون 'draft' أو 'approved'."}

        # توليد رقم التقرير
        count = await conn.fetchval("SELECT COUNT(*) FROM reports") or 0
        year = datetime.now(timezone.utc).year
        report_number = f"LAB-RPT-{year}-{count + 1:04d}"

        # بناء محتوى التقرير النهائي
        report_content = {
            "title": draft["title"],
            "type": draft["draft_type"],
            "parameters": json.loads(draft["parameters"]) if draft["parameters"] else {},
            "inventory_snapshot": json.loads(draft["inventory_snapshot"]) if draft["inventory_snapshot"] else {},
            "computed_stats": json.loads(draft["computed_stats"]) if draft["computed_stats"] else {},
            "generated_by_ai": draft["generated_by_ai"],
        }

        metadata = {
            "lab_name": "مختبر المنصة الطبية",
            "report_number": report_number,
            "sealed_by_user": user_id,
            "server_time_utc": datetime.now(timezone.utc).isoformat(),
            "draft_hash": draft["hash_draft"],
        }

        # استدعاء دالة الختم من قاعدة البيانات
        row = await conn.fetchrow("""
            INSERT INTO reports (
                report_number, draft_id, title, report_type,
                content, metadata, version, is_latest, status
            ) VALUES ($1, $2, $3, $4, $5, $6, 1, true, 'pending_seal')
            RETURNING id
        """, report_number, draft_id, draft["title"], draft["draft_type"],
             json.dumps(report_content, default=str, ensure_ascii=False),
             json.dumps(metadata, default=str, ensure_ascii=False))

        report_id = row["id"]

        # ختم رقمي
        seal_result = await conn.fetchrow("""
            SELECT seal_report($1::uuid, $2::uuid)
        """, report_id, user_id)

        seal_data = json.loads(seal_result[0]) if seal_result[0] else {}

        # تحديث حالة المسودة
        await conn.execute("""
            UPDATE report_drafts SET status = 'sealed', reviewed_by = $1, reviewed_at = NOW()
            WHERE id = $2
        """, user_id, draft_id)

    await log_audit(
        pool, "create", "report", str(report_id),
        f"user:{user_id}", "Seal Report",
        new_values={"report_number": report_number, "digital_seal": seal_data.get("digital_seal")},
        mcp_tool="seal_report"
    )

    return {
        "status": "sealed",
        "report_id": str(report_id),
        "report_number": report_number,
        "digital_seal": seal_data.get("digital_seal"),
        "qr_data": seal_data.get("qr_data"),
        "title": draft["title"],
        "message": f"✅ تم ختم التقرير {report_number} رقمياً. لا يمكن تعديله بعد الآن.",
    }


async def handle_get_report_history(pool: asyncpg.Pool, args: dict) -> dict:
    """★ عرض سجل التقارير"""
    status = args.get("status", "all")
    report_type = args.get("report_type")
    offset = args.get("offset", 0)

    conditions = []
    params = []
    idx = 1

    if status != "all":
        conditions.append(f"r.status = ${idx}")
        params.append(status)
        idx += 1
    if report_type:
        conditions.append(f"r.report_type = ${idx}")
        params.append(report_type)
        idx += 1

    where = "WHERE " + " AND ".join(conditions) if conditions else ""

    async with pool.acquire() as conn:
        rows = await conn.fetch(f"""
            SELECT
                r.id, r.report_number, r.title, r.report_type,
                r.status, r.version, r.is_latest,
                r.digital_seal, r.sealed_at,
                u.full_name AS sealed_by_name,
                r.created_at
            FROM reports r
            LEFT JOIN users u ON r.sealed_by = u.id
            {where}
            ORDER BY r.created_at DESC
            LIMIT {MAX_ROWS_PER_RESPONSE + 1} OFFSET ${idx}
        """, *params, offset)

        total = await conn.fetchval(f"""
            SELECT COUNT(*) FROM reports r {where}
        """, *params)

        rows_dict = [dict(r) for r in rows[:MAX_ROWS_PER_RESPONSE]]
        return paginate_results(rows_dict, MAX_ROWS_PER_RESPONSE) | {
            "pagination": {"total": total, "offset": offset, "has_more": len(rows) > MAX_ROWS_PER_RESPONSE}
        }


async def handle_process_offline_queue(pool: asyncpg.Pool, args: dict) -> dict:
    """★ معالجة طابور الاتصال المقطوع"""
    limit = args.get("limit", 10)

    async with pool.acquire() as conn:
        rows = await conn.fetch("""
            SELECT * FROM process_offline_queue($1)
        """, limit)

        if not rows:
            return {"status": "empty", "message": "لا توجد إجراءات معلقة في الطابور"}

        items = [dict(r) for r in rows]

        return {
            "status": "processing",
            "items_count": len(items),
            "items": items,
            "note": "تم تسليم الإجراءات للمعالجة. تحقق من الحالة لاحقاً."
        }


# =============================================================================
# Helpers
# =============================================================================

async def _get_product_name(pool: asyncpg.Pool, product_id: str) -> str:
    async with pool.acquire() as conn:
        row = await conn.fetchval("SELECT name_ar FROM products WHERE id = $1", product_id)
        return row or "غير معروف"


# =============================================================================
# Server Entry Point
# =============================================================================

async def main():
    logger.info("Starting Lab Inventory MCP Server (FEFO + MKT + Alerts + Reports)...")
    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options()
        )

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    asyncio.run(main())
