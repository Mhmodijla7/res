/**
 * AIMode.tsx — دردشة ذكية مع Goose عبر WebSocket
 *
 * ★ يتضمن:
 * - تفكيك النوايا الصوتية الغامضة (Intent Deconstruction)
 * - عرض مسودات الإجراءات (Draft Actions) للموافقة
 * - معالجة تجاوز حدود الـ Output Tokens
 * - تكامل مع Human-in-the-Loop
 * - ★ computeStats: حساب FEFO باستخدام وقت السيرفر (ليس المحلي)
 * - ★ ExpiryAlertBanner: تنبيهات الصلاحية النشطة
 * - ★ ReportDraftPreview: معاينة مسودات التقارير
 * - ★ OfflineQueue: طابور اتصال محلي
 */

'use client';

import React, { useState, useRef, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Bot, User, Send, Mic, MicOff, Loader2,
  CheckCircle, XCircle, AlertTriangle, Clock,
  Volume2, Copy, ThumbsUp, ThumbsDown,
  Shield, ArrowRight, RotateCcw, FileText,
  TrendingDown, Activity, Wifi, WifiOff
} from 'lucide-react';

// =============================================================================
// Types
// =============================================================================

interface DraftAction {
  id: string;
  description: string;
  tool_name: string;
  parameters: Record<string, any>;
  confidence: number;
  risk_level: 'low' | 'medium' | 'high' | 'critical';
  requires_approval: boolean;
  estimated_impact: string;
  alternatives?: string[];
}

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system' | 'tool' | 'draft';
  content: string;
  timestamp: Date;
  voice_input?: boolean;
  whisper_transcript?: string;
  draft_action?: DraftAction;
  draft_status?: 'pending' | 'approved' | 'rejected' | 'modified';
  tool_calls?: Array<{ name: string; result: any; status: string }>;
  is_streaming?: boolean;
  pagination_hint?: {
    has_more: boolean;
    offset: number;
    total: number;
    instruction: string;
    returned?: number;
    truncated?: boolean;
  };
}

interface AIModeProps {
  wsUrl?: string;
  onDraftApproved?: (draft: DraftAction) => void;
  onDraftRejected?: (draft: DraftAction, reason: string) => void;
}

// =============================================================================
// ★ NEW: Lab Item Interface (for computeStats)
// =============================================================================

interface LabItem {
  id: string;
  sku: string;
  name_ar: string;
  expiry_date: string | null;
  batch_number?: string;
  current_quantity: number;
  storage_zone?: string;
  remaining_shelf_pct?: number;
  requires_fefo?: boolean;
}

interface ComputedStats {
  total_items: number;
  expired_count: number;
  near_expiry_count: number;
  critical_count: number;
  compliant_count: number;
  computed_at: string;
  server_time: string;
}

interface ExpiryAlert {
  id: string;
  alert_level: 'info' | 'warning' | 'critical' | 'expired';
  days_until_expiry: number;
  batch_number: string;
  current_quantity: number;
  expiry_date: string;
  product_name: string;
  sku: string;
  acknowledged: boolean;
}

interface OfflineQueueItem {
  id: string;
  action_type: string;
  payload: Record<string, any>;
  client_timestamp: string;
  status: 'pending' | 'processing' | 'completed' | 'failed';
}

// =============================================================================
// ★ NEW: computeStats — FEFO-aware statistics using server time
// =============================================================================

/**
 * ★ حساب إحصائيات المخزون باستخدام وقت السيرفر (ليس وقت الجهاز المحلي).
 *
 * القاعدة الذهبية: لا تعتمد أبداً على new Date() للمناطق الزمنية المختلفة.
 * استخدم دائماً GET /api/server-time أو get_server_time MCP tool.
 *
 * @param items - قائمة الأصناف المخبرية
 * @param serverTimeUtc - وقت السيرفر بصيغة ISO 8601 (من get_server_time)
 * @returns ComputedStats مع expired/near_expiry/critical counts
 */
async function computeStats(
  items: LabItem[],
  serverTimeUtc?: string
): Promise<ComputedStats> {
  // ★ القاعدة: لا نستخدم new Date() أبداً — نستخدم وقت السيرفر
  let today: Date;
  if (serverTimeUtc) {
    today = new Date(serverTimeUtc);
  } else {
    // احتياطي: اطلب من API (ليس من الجهاز)
    try {
      const resp = await fetch('/api/server-time');
      const data = await resp.json();
      today = new Date(data.utc);
    } catch {
      // آخر احتمال: استخدم UTC صريحاً
      today = new Date(new Date().toISOString());
    }
  }

  let expired = 0;
  let nearExpiry = 0;
  let critical = 0;
  let compliant = 0;

  for (const item of items) {
    if (!item.expiry_date) {
      compliant++;
      continue;
    }

    const expiry = new Date(item.expiry_date);
    const msLeft = expiry.getTime() - today.getTime();
    const daysLeft = Math.floor(msLeft / (1000 * 60 * 60 * 24));

    if (daysLeft <= 0) {
      expired++;
    } else if (daysLeft <= 15) {
      critical++;
    } else if (daysLeft <= 30) {
      nearExpiry++;
    } else {
      compliant++;
    }
  }

  return {
    total_items: items.length,
    expired_count: expired,
    near_expiry_count: nearExpiry,
    critical_count: critical,
    compliant_count: compliant,
    computed_at: today.toISOString(),
    server_time: serverTimeUtc || today.toISOString(),
  };
}


// =============================================================================
// ★ NEW: Expiry Alert Banner
// =============================================================================

function ExpiryAlertBanner({
  alerts,
  onAcknowledge
}: {
  alerts: ExpiryAlert[];
  onAcknowledge?: (alertId: string, action: string) => void;
}) {
  if (!alerts || alerts.length === 0) return null;

  const expired = alerts.filter(a => a.alert_level === 'expired');
  const critical = alerts.filter(a => a.alert_level === 'critical');
  const warning = alerts.filter(a => a.alert_level === 'warning');

  if (expired.length === 0 && critical.length === 0 && warning.length === 0) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-gradient-to-r from-red-50 to-orange-50 border border-red-200 rounded-xl p-3 mb-3"
    >
      <div className="flex items-center gap-2 mb-2">
        <AlertTriangle className="text-red-500" size={16} />
        <span className="font-bold text-sm text-red-700">تنبيهات الصلاحية</span>
        <span className="text-xs text-gray-400 mr-auto">{alerts.length} تنبيه</span>
      </div>

      <div className="space-y-1">
        {expired.length > 0 && (
          <div className="flex items-center gap-2 text-xs">
            <span className="w-2 h-2 rounded-full bg-red-500" />
            <span className="text-red-600 font-medium">
              {expired.length} منتج منتهي الصلاحية — يجب الإخلاء فوراً
            </span>
          </div>
        )}
        {critical.length > 0 && (
          <div className="flex items-center gap-2 text-xs">
            <span className="w-2 h-2 rounded-full bg-orange-500" />
            <span className="text-orange-600 font-medium">
              {critical.length} دفعة تنتهي خلال 15 يوم
            </span>
          </div>
        )}
        {warning.length > 0 && (
          <div className="flex items-center gap-2 text-xs">
            <span className="w-2 h-2 rounded-full bg-yellow-500" />
            <span className="text-yellow-600">
              {warning.length} دفعة تنتهي خلال 30 يوم
            </span>
          </div>
        )}
      </div>

      {onAcknowledge && alerts.length > 0 && (
        <button
          onClick={() => onAcknowledge(alerts[0].id, 'consumed')}
          className="mt-2 text-xs text-indigo-600 hover:text-indigo-800 underline"
        >
          عرض التفاصيل والتعامل مع التنبيهات ←
        </button>
      )}
    </motion.div>
  );
}


// =============================================================================
// ★ NEW: Report Draft Preview Card
// =============================================================================

function ReportDraftPreview({
  draft,
  onApprove,
  onReject
}: {
  draft: {
    id: string;
    title: string;
    draft_type: string;
    hash_draft: string;
    snapshot_summary?: Record<string, any>;
  };
  onApprove: () => void;
  onReject: () => void;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="rounded-xl border-2 border-indigo-200 bg-indigo-50 p-4"
    >
      <div className="flex items-center gap-2 mb-3">
        <FileText className="text-indigo-500" size={18} />
        <span className="font-bold text-sm text-indigo-700">مسودة تقرير — بانتظار المراجعة</span>
      </div>

      <div className="space-y-2 text-sm">
        <div className="flex justify-between">
          <span className="text-gray-500">العنوان:</span>
          <span className="font-medium">{draft.title}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-gray-500">النوع:</span>
          <span className="font-mono text-xs bg-white px-2 py-0.5 rounded">{draft.draft_type}</span>
        </div>
        {draft.snapshot_summary && (
          <>
            {draft.snapshot_summary.has_fefo_stats && (
              <div className="flex items-center gap-1 text-xs text-green-600">
                <CheckCircle size={12} />
                <span>إحصائيات FEFO مُضمّنة</span>
              </div>
            )}
            {draft.snapshot_summary.low_stock_count > 0 && (
              <div className="flex items-center gap-1 text-xs text-orange-600">
                <TrendingDown size={12} />
                <span>{draft.snapshot_summary.low_stock_count} منتج منخفض المخزون</span>
              </div>
            )}
          </>
        )}
        <div className="text-[10px] text-gray-400 font-mono mt-2">
          Hash: {draft.hash_draft?.substring(0, 16)}...
        </div>
      </div>

      <div className="flex items-center gap-2 mt-4">
        <button
          onClick={onApprove}
          className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl bg-indigo-600 text-white text-sm font-bold hover:bg-indigo-700 transition-colors"
        >
          <CheckCircle size={14} />
          مراجعة واعتماد
        </button>
        <button
          onClick={onReject}
          className="py-2 px-4 rounded-xl bg-white text-gray-600 text-sm border border-gray-200 hover:bg-gray-50 transition-colors"
        >
          تعديل
        </button>
      </div>
    </motion.div>
  );
}


// =============================================================================
// ★ NEW: Offline Queue Hook
// =============================================================================

function useOfflineQueue() {
  const [isOnline, setIsOnline] = useState(true);
  const [queue, setQueue] = useState<OfflineQueueItem[]>([]);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    setIsOnline(navigator.onLine);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // عند عودة الاتصال: أرسل الطابور
  useEffect(() => {
    if (isOnline && queue.length > 0) {
      const flushQueue = async () => {
        try {
          const response = await fetch('/api/offline-queue/flush', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ items: queue }),
          });
          if (response.ok) {
            setQueue([]);
          }
        } catch {
          // سيبقى في الطابور
        }
      };
      flushQueue();
    }
  }, [isOnline, queue]);

  const enqueue = useCallback((action: string, payload: Record<string, any>) => {
    const item: OfflineQueueItem = {
      id: `offline-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
      action_type: action,
      payload,
      client_timestamp: new Date().toISOString(),
      status: 'pending',
    };
    setQueue(prev => [...prev, item]);
    return item.id;
  }, []);

  return { isOnline, queue, enqueue, queueSize: queue.length };
}


// =============================================================================
// Intent Classification
// =============================================================================

type IntentConfidence = 'high' | 'medium' | 'low' | 'ambiguous';

interface ClassifiedIntent {
  primary_intent: string;
  confidence: IntentConfidence;
  entities: Record<string, string>;
  conditions: string[];
  is_conditional: boolean;
  ambiguity_reason?: string;
  clarification_question?: string;
}

function classifyVoiceIntent(transcript: string): ClassifiedIntent {
  const text = transcript.trim().toLowerCase();

  const conditional_markers = [
    'إذا', 'ان', 'لو', ' במידה ', 'شرط',
    'maybe', 'if', 'when', 'provided'
  ];
  const approval_markers = [
    'وافق', 'أوافق', 'موافق', 'تمام', 'حسناً', 'نعم',
    'approve', 'agree', 'confirm', 'yes', 'okay'
  ];
  const query_markers = [
    'اعرض', 'أعطني', 'ما هو', 'كم', 'كيف', 'أين', 'لماذا',
    'show', 'give', 'what', 'how', 'where', 'why', 'list'
  ];
  const action_markers = [
    'احذف', 'أضف', 'عدّل', 'حدّث', 'أرسل', 'أنشئ',
    'delete', 'add', 'update', 'send', 'create', 'modify'
  ];

  const has_condition = conditional_markers.some(m => text.includes(m));
  const has_approval = approval_markers.some(m => text.includes(m));
  const has_query = query_markers.some(m => text.includes(m));
  const has_action = action_markers.some(m => text.includes(m));

  let confidence: IntentConfidence = 'high';
  let ambiguity_reason: string | undefined;
  let clarification: string | undefined;

  if (has_condition && has_approval) {
    confidence = 'ambiguous';
    ambiguity_reason = 'الموافقة مشروطة بشروط غير محددة';
    clarification = 'ما المقصود بـ "السعر المناسب"؟ هل تقصد أقل من مبلغ معين؟';
  } else if (has_condition && has_action) {
    confidence = 'low';
    ambiguity_reason = 'الإجراء مشروط';
    clarification = 'يرجى توضيح الشرط قبل تنفيذ الإجراء';
  } else if (has_action && !has_condition) {
    confidence = 'high';
  } else if (has_query) {
    confidence = 'high';
  }

  const entities: Record<string, string> = {};
  const number_match = text.match(/(\d[\d,\.]*)/);
  if (number_match) {
    entities['number'] = number_match[1];
  }

  const conditions: string[] = [];
  if (has_condition) {
    const condIdx = text.indexOf('إذا');
    const loIdx = text.indexOf('لو');
    const startIdx = condIdx > -1 ? condIdx : loIdx;
    if (startIdx > -1) {
      conditions.push(text.substring(startIdx));
    }
  }

  let primary_intent = 'unknown';
  if (has_approval) primary_intent = 'approve';
  else if (has_action) primary_intent = 'execute_action';
  else if (has_query) primary_intent = 'query';

  return {
    primary_intent,
    confidence,
    entities,
    conditions,
    is_conditional: has_condition,
    ambiguity_reason,
    clarification_question: clarification,
  };
}


// =============================================================================
// WebSocket Hook
// =============================================================================

function useGooseSocket(url: string) {
  const [connected, setConnected] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [expiryAlerts, setExpiryAlerts] = useState<ExpiryAlert[]>([]);
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimer = useRef<NodeJS.Timeout>();

  const connect = useCallback(() => {
    try {
      const ws = new WebSocket(url);
      wsRef.current = ws;

      ws.onopen = () => {
        setConnected(true);
        setMessages(prev => [...prev, {
          id: `sys-${Date.now()}`,
          role: 'system',
          content: '🟢 متصل بـ Goose AI. جاهز للأوامر.',
          timestamp: new Date(),
        }]);
        // طلب التنبيهات عند الاتصال
        ws.send(JSON.stringify({ type: 'get_alerts' }));
      };

      ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          handleServerMessage(data);
        } catch {
          handleStreamChunk(event.data);
        }
      };

      ws.onclose = () => {
        setConnected(false);
        reconnectTimer.current = setTimeout(connect, 3000);
      };

      ws.onerror = () => {
        setConnected(false);
      };
    } catch {
      setConnected(false);
    }
  }, [url]);

  const handleServerMessage = useCallback((data: any) => {
    if (data.type === 'draft_action') {
      const draft: DraftAction = data.draft;
      setMessages(prev => [...prev, {
        id: `draft-${Date.now()}`,
        role: 'draft',
        content: `📋 مسودة إجراء: ${draft.description}`,
        timestamp: new Date(),
        draft_action: draft,
        draft_status: 'pending',
      }]);
    } else if (data.type === 'report_draft') {
      // ★ NEW: استقبال مسودة تقرير
      setMessages(prev => [...prev, {
        id: `rpt-draft-${Date.now()}`,
        role: 'draft',
        content: `📄 مسودة تقرير: ${data.draft.title}`,
        timestamp: new Date(),
        draft_action: {
          id: data.draft.id,
          description: `تقرير: ${data.draft.title}`,
          tool_name: 'create_report_draft',
          parameters: data.draft,
          confidence: 100,
          risk_level: 'medium',
          requires_approval: true,
          estimated_impact: 'إنشاء تقرير رسمي مختوم',
        },
        draft_status: 'pending',
      }]);
    } else if (data.type === 'expiry_alerts') {
      // ★ NEW: استقبال تنبيهات الصلاحية
      setExpiryAlerts(data.alerts || []);
    } else if (data.type === 'tool_result') {
      setMessages(prev => [...prev, {
        id: `tool-${Date.now()}`,
        role: 'tool',
        content: JSON.stringify(data.result, null, 2),
        timestamp: new Date(),
        tool_calls: [{ name: data.tool, result: data.result, status: data.status }],
        pagination_hint: data.result?.pagination,
      }]);
    } else if (data.type === 'stream_start') {
      setMessages(prev => [...prev, {
        id: `stream-${Date.now()}`,
        role: 'assistant',
        content: '',
        timestamp: new Date(),
        is_streaming: true,
      }]);
    } else if (data.type === 'stream_end') {
      setMessages(prev => {
        const updated = [...prev];
        const last = updated[updated.length - 1];
        if (last?.is_streaming) {
          last.is_streaming = false;
        }
        return updated;
      });
    } else if (data.type === 'response') {
      setMessages(prev => [...prev, {
        id: `resp-${Date.now()}`,
        role: 'assistant',
        content: data.content,
        timestamp: new Date(),
      }]);
    }
  }, []);

  const handleStreamChunk = useCallback((chunk: string) => {
    setMessages(prev => {
      const updated = [...prev];
      const last = updated[updated.length - 1];
      if (last?.is_streaming) {
        last.content += chunk;
      }
      return [...updated];
    });
  }, []);

  useEffect(() => {
    connect();
    return () => {
      if (reconnectTimer.current) clearTimeout(reconnectTimer.current);
      wsRef.current?.close();
    };
  }, [connect]);

  const sendMessage = useCallback((text: string, isVoice: boolean = false) => {
    if (!wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) return;

    let intent: ClassifiedIntent | undefined;
    if (isVoice) {
      intent = classifyVoiceIntent(text);

      if (intent.confidence === 'ambiguous' || intent.confidence === 'low') {
        setMessages(prev => [...prev, {
          id: `user-${Date.now()}`,
          role: 'user',
          content: `🎤 ${text}`,
          timestamp: new Date(),
          voice_input: true,
          whisper_transcript: text,
        }, {
          id: `clarify-${Date.now()}`,
          role: 'assistant',
          content: `🤔 ${intent.clarification_question || 'لم أفهم نيتك بالضبط. هل تقصد:'}`,
          timestamp: new Date(),
          draft_action: {
            id: `draft-${Date.now()}`,
            description: `إجراء مقترح بناءً على: "${text}"`,
            tool_name: 'unknown',
            parameters: intent.entities,
            confidence: intent.confidence === 'ambiguous' ? 30 : 50,
            risk_level: 'medium',
            requires_approval: true,
            estimated_impact: intent.ambiguity_reason || '',
            alternatives: [
              'نعم، هذا ما أقصده',
              'لا، أعني شيئاً آخر',
              'أريد تعديل الأمر',
            ],
          },
          draft_status: 'pending',
        }]);
        return;
      }
    }

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: text,
      timestamp: new Date(),
      voice_input: isVoice,
      whisper_transcript: isVoice ? text : undefined,
    };
    setMessages(prev => [...prev, userMsg]);

    wsRef.current.send(JSON.stringify({
      type: 'message',
      content: text,
      voice: isVoice,
      intent: intent || undefined,
    }));
  }, []);

  const approveDraft = useCallback((draftId: string) => {
    setMessages(prev => prev.map(m =>
      m.id === draftId ? { ...m, draft_status: 'approved' } : m
    ));

    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: 'draft_response',
        draft_id: draftId,
        approved: true,
      }));
    }
  }, []);

  const rejectDraft = useCallback((draftId: string, reason?: string) => {
    setMessages(prev => prev.map(m =>
      m.id === draftId ? { ...m, draft_status: 'rejected' } : m
    ));

    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: 'draft_response',
        draft_id: draftId,
        approved: false,
        reason: reason || 'رفض المستخدم',
      }));
    }
  }, []);

  const loadMore = useCallback((offset: number) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: 'load_more',
        offset,
      }));
    }
  }, []);

  return {
    connected,
    messages,
    expiryAlerts,
    sendMessage,
    approveDraft,
    rejectDraft,
    loadMore,
  };
}


// =============================================================================
// Voice Recording Hook
// =============================================================================

function useVoiceRecording() {
  const [isRecording, setIsRecording] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const mediaRecorder = useRef<MediaRecorder | null>(null);
  const audioChunks = useRef<Blob[]>([]);

  const startRecording = useCallback(async (onResult: (text: string) => void) => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream, {
        mimeType: 'audio/webm;codecs=opus'
      });

      audioChunks.current = [];

      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) audioChunks.current.push(e.data);
      };

      recorder.onstop = async () => {
        setIsProcessing(true);
        const audioBlob = new Blob(audioChunks.current, { type: 'audio/webm' });

        const formData = new FormData();
        formData.append('audio', audioBlob, 'recording.webm');
        formData.append('language', 'ar');

        try {
          const response = await fetch('/api/speech/transcribe', {
            method: 'POST',
            body: formData,
          });
          const data = await response.json();
          if (data.text) {
            onResult(data.text);
          }
        } catch (err) {
          console.error('Transcription error:', err);
        } finally {
          setIsProcessing(false);
          stream.getTracks().forEach(t => t.stop());
        }
      };

      mediaRecorder.current = recorder;
      recorder.start();
      setIsRecording(true);
    } catch (err) {
      console.error('Microphone error:', err);
    }
  }, []);

  const stopRecording = useCallback(() => {
    if (mediaRecorder.current && isRecording) {
      mediaRecorder.current.stop();
      setIsRecording(false);
    }
  }, [isRecording]);

  return { isRecording, isProcessing, startRecording, stopRecording };
}


// =============================================================================
// Draft Action Card
// =============================================================================

function DraftActionCard({
  draft,
  status,
  onApprove,
  onReject,
}: {
  draft: DraftAction;
  status: 'pending' | 'approved' | 'rejected' | 'modified';
  onApprove: () => void;
  onReject: (reason?: string) => void;
}) {
  const [rejectionReason, setRejectionReason] = useState('');
  const [showRejectForm, setShowRejectForm] = useState(false);

  const riskColors = {
    low: 'border-green-200 bg-green-50',
    medium: 'border-yellow-200 bg-yellow-50',
    high: 'border-orange-200 bg-orange-50',
    critical: 'border-red-200 bg-red-50',
  };

  const riskIcons = {
    low: <CheckCircle className="text-green-500" size={16} />,
    medium: <AlertTriangle className="text-yellow-500" size={16} />,
    high: <AlertTriangle className="text-orange-500" size={16} />,
    critical: <Shield className="text-red-500" size={16} />,
  };

  const statusColors = {
    approved: 'bg-green-100 text-green-700 border-green-200',
    rejected: 'bg-red-100 text-red-700 border-red-200',
    pending: '',
    modified: 'bg-blue-100 text-blue-700 border-blue-200',
  };

  if (status === 'approved') {
    return (
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className={`rounded-xl border p-4 ${statusColors.approved}`}
      >
        <div className="flex items-center gap-2 mb-2">
          <CheckCircle size={18} />
          <span className="font-bold text-sm">تمت الموافقة</span>
        </div>
        <p className="text-sm">{draft.description}</p>
      </motion.div>
    );
  }

  if (status === 'rejected') {
    return (
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className={`rounded-xl border p-4 ${statusColors.rejected}`}
      >
        <div className="flex items-center gap-2 mb-2">
          <XCircle size={18} />
          <span className="font-bold text-sm">تم الرفض</span>
        </div>
        <p className="text-sm">{draft.description}</p>
      </motion.div>
    );
  }

  // Report draft preview
  if (draft.tool_name === 'create_report_draft' && draft.parameters?.id) {
    return (
      <ReportDraftPreview
        draft={draft.parameters}
        onApprove={onApprove}
        onReject={() => setShowRejectForm(true)}
      />
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className={`rounded-xl border-2 p-4 ${riskColors[draft.risk_level]}`}
    >
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          {riskIcons[draft.risk_level]}
          <span className="font-bold text-sm">مسودة إجراء</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs px-2 py-0.5 rounded-full bg-white/70 font-mono">
            {draft.tool_name}
          </span>
          <span className="text-xs text-gray-500">
            ثقة: {draft.confidence}%
          </span>
        </div>
      </div>

      <p className="text-sm text-gray-700 mb-3 leading-relaxed">
        {draft.description}
      </p>

      {draft.estimated_impact && (
        <div className="text-xs text-gray-500 mb-3 flex items-start gap-1">
          <ArrowRight size={14} className="mt-0.5 shrink-0" />
          <span>{draft.estimated_impact}</span>
        </div>
      )}

      {Object.keys(draft.parameters).length > 0 && (
        <details className="mb-3">
          <summary className="text-xs text-gray-400 cursor-pointer hover:text-gray-600">
            التفاصيل التقنية
          </summary>
          <pre className="mt-2 text-xs bg-white/50 rounded-lg p-2 overflow-x-auto">
            {JSON.stringify(draft.parameters, null, 2)}
          </pre>
        </details>
      )}

      {draft.alternatives && draft.alternatives.length > 0 && (
        <div className="mb-3">
          <p className="text-xs text-gray-400 mb-1">بدائل:</p>
          <div className="flex flex-wrap gap-1.5">
            {draft.alternatives.map((alt, i) => (
              <button
                key={i}
                className="text-xs px-2 py-1 rounded-full bg-white/70 hover:bg-white border border-gray-200 transition-colors"
              >
                {alt}
              </button>
            ))}
          </div>
        </div>
      )}

      {!showRejectForm ? (
        <div className="flex items-center gap-2">
          <button
            onClick={onApprove}
            className="flex-1 flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-green-500 text-white font-bold text-sm hover:bg-green-600 transition-colors shadow-sm"
          >
            <ThumbsUp size={16} />
            موافقة وتنفيذ
          </button>
          <button
            onClick={() => setShowRejectForm(true)}
            className="flex-1 flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-white text-red-600 font-bold text-sm hover:bg-red-50 transition-colors border border-red-200"
          >
            <ThumbsDown size={16} />
            رفض
          </button>
        </div>
      ) : (
        <div className="space-y-2">
          <textarea
            value={rejectionReason}
            onChange={(e) => setRejectionReason(e.target.value)}
            placeholder="سبب الرفض (اختياري)..."
            className="w-full text-sm p-2 rounded-lg border border-red-200 resize-none focus:ring-2 focus:ring-red-200 outline-none"
            rows={2}
          />
          <div className="flex items-center gap-2">
            <button
              onClick={() => onReject(rejectionReason)}
              className="flex-1 py-2 rounded-xl bg-red-500 text-white text-sm font-bold hover:bg-red-600 transition-colors"
            >
              تأكيد الرفض
            </button>
            <button
              onClick={() => setShowRejectForm(false)}
              className="py-2 px-4 rounded-xl bg-gray-100 text-gray-600 text-sm hover:bg-gray-200 transition-colors"
            >
              <RotateCcw size={14} />
            </button>
          </div>
        </div>
      )}
    </motion.div>
  );
}


// =============================================================================
// Pagination Banner
// =============================================================================

function PaginationBanner({
  hint,
  onLoadMore,
}: {
  hint: NonNullable<ChatMessage['pagination_hint']>;
  onLoadMore: () => void;
}) {
  return (
    <div className="flex items-center justify-between bg-blue-50 rounded-lg p-3 border border-blue-100">
      <div className="text-xs text-blue-600">
        <span className="font-bold">{hint.returned ?? '?'}</span> من{' '}
        <span className="font-bold">{hint.total}</span> نتيجة
        {hint.truncated && (
          <span className="ml-1 text-blue-400">(تم اقتطاع النتائج)</span>
        )}
      </div>
      {hint.has_more && (
        <button
          onClick={onLoadMore}
          className="text-xs px-3 py-1 rounded-lg bg-blue-500 text-white font-bold hover:bg-blue-600 transition-colors"
        >
          تحميل المزيد
        </button>
      )}
    </div>
  );
}


// =============================================================================
// Chat Message Bubble
// =============================================================================

function MessageBubble({
  msg,
  onApprove,
  onReject,
  onLoadMore,
}: {
  msg: ChatMessage;
  onApprove: (id: string) => void;
  onReject: (id: string, reason?: string) => void;
  onLoadMore: (offset: number) => void;
}) {
  const isUser = msg.role === 'user';
  const isSystem = msg.role === 'system';
  const isDraft = msg.role === 'draft';
  const isTool = msg.role === 'tool';

  const bubbleStyles = {
    user: 'bg-indigo-600 text-white ml-12',
    assistant: 'bg-gray-100 text-gray-800 mr-12',
    system: 'bg-blue-50 text-blue-600 text-center text-xs',
    tool: 'bg-gray-50 text-gray-600 mr-12 border border-gray-200',
    draft: 'mr-12',
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className={`flex ${isUser ? 'justify-end' : 'justify-start'}`}
    >
      <div className={`max-w-[85%] ${bubbleStyles[msg.role]}`}>
        {!isUser && !isSystem && !isDraft && (
          <div className="flex items-center gap-2 mb-1 px-1">
            {isTool ? (
              <span className="text-xs text-gray-400 font-mono">🔧 MCP Tool</span>
            ) : (
              <>
                <Bot size={14} className="text-indigo-400" />
                <span className="text-xs text-gray-400">Goose AI</span>
              </>
            )}
          </div>
        )}

        {isDraft && msg.draft_action ? (
          <DraftActionCard
            draft={msg.draft_action}
            status={msg.draft_status || 'pending'}
            onApprove={() => onApprove(msg.id)}
            onReject={(reason) => onReject(msg.id, reason)}
          />
        ) : (
          <div className={`rounded-2xl px-4 py-3 text-sm leading-relaxed ${bubbleStyles[msg.role]}`}>
            {msg.voice_input && (
              <div className="flex items-center gap-1 mb-1 text-xs opacity-70">
                <Volume2 size={12} />
                <span>إدخال صوتي</span>
              </div>
            )}

            <p className="whitespace-pre-wrap">{msg.content}</p>

            {msg.is_streaming && (
              <span className="inline-block w-2 h-4 bg-indigo-400 animate-pulse ml-1" />
            )}
          </div>
        )}

        {msg.pagination_hint && msg.pagination_hint.has_more && (
          <div className="mt-2">
            <PaginationBanner
              hint={msg.pagination_hint}
              onLoadMore={() => onLoadMore(msg.pagination_hint!.offset)}
            />
          </div>
        )}

        <div className={`flex items-center gap-1 mt-1 px-1 ${isUser ? 'justify-end' : 'justify-start'}`}>
          <Clock size={10} className="text-gray-300" />
          <span className="text-[10px] text-gray-300">
            {msg.timestamp.toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' })}
          </span>
        </div>
      </div>
    </motion.div>
  );
}


// =============================================================================
// Main AIMode Component
// =============================================================================

export function AIMode({ wsUrl = 'ws://localhost:8080/ws/goose', onDraftApproved, onDraftRejected }: AIModeProps) {
  const [inputText, setInputText] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const {
    connected,
    messages,
    expiryAlerts,
    sendMessage,
    approveDraft,
    rejectDraft,
    loadMore,
  } = useGooseSocket(wsUrl);

  const {
    isRecording,
    isProcessing,
    startRecording,
    stopRecording,
  } = useVoiceRecording();

  // ★ NEW: Offline queue
  const { isOnline, queueSize } = useOfflineQueue();

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = useCallback(() => {
    const text = inputText.trim();
    if (!text) return;
    sendMessage(text, false);
    setInputText('');
    inputRef.current?.focus();
  }, [inputText, sendMessage]);

  const handleVoice = useCallback(() => {
    if (isRecording) {
      stopRecording();
    } else {
      startRecording((transcript) => {
        sendMessage(transcript, true);
      });
    }
  }, [isRecording, startRecording, stopRecording, sendMessage]);

  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  }, [handleSend]);

  return (
    <div className="flex flex-col h-full">
      {/* شريط الحالة */}
      <div className="flex items-center justify-between px-4 py-2 border-b bg-gray-50/50">
        <div className="flex items-center gap-2">
          <div className={`w-2 h-2 rounded-full ${connected ? 'bg-green-400 animate-pulse' : 'bg-red-400'}`} />
          <span className="text-xs text-gray-500">
            {connected ? 'متصل بـ Goose' : 'غير متصل — إعادة المحاولة...'}
          </span>
          {/* ★ NEW: مؤشر الاتصال */}
          {!isOnline && (
            <span className="flex items-center gap-1 text-xs text-orange-500">
              <WifiOff size={12} />
              <span>غير متصل بالإنترنت ({queueSize} في الطابور)</span>
            </span>
          )}
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs text-gray-400">
            {messages.filter(m => m.role !== 'system').length} رسالة
          </span>
        </div>
      </div>

      {/* ★ NEW: Expiry Alert Banner */}
      <ExpiryAlertBanner
        alerts={expiryAlerts}
        onAcknowledge={(alertId, action) => {
          sendMessage(`أقر التنبيه ${alertId} — الإجراء: ${action}`, false);
        }}
      />

      {/* منطقة الرسائل */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        <AnimatePresence>
          {messages.map((msg) => (
            <MessageBubble
              key={msg.id}
              msg={msg}
              onApprove={(id) => {
                approveDraft(id);
                onDraftApproved?.(msg.draft_action!);
              }}
              onReject={(id, reason) => {
                rejectDraft(id, reason);
                onDraftRejected?.(msg.draft_action!, reason || '');
              }}
              onLoadMore={(offset) => loadMore(offset)}
            />
          ))}
        </AnimatePresence>
        <div ref={messagesEndRef} />
      </div>

      {/* شريط الإدخال */}
      <div className="p-4 border-t bg-white">
        {(isRecording || isProcessing) && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            className="mb-3 flex items-center justify-center gap-2 text-sm"
          >
            {isRecording ? (
              <>
                <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse" />
                <span className="text-red-600 font-medium">جاري التسجيل... انقر للإيقاف</span>
              </>
            ) : (
              <>
                <Loader2 size={16} className="animate-spin text-indigo-500" />
                <span className="text-indigo-600">جاري تحويل الصوت إلى نص...</span>
              </>
            )}
          </motion.div>
        )}

        <div className="flex items-center gap-2">
          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={handleVoice}
            className={`
              p-3 rounded-xl transition-all duration-200
              ${isRecording
                ? 'bg-red-500 text-white shadow-lg shadow-red-200 animate-pulse'
                : 'bg-gray-100 text-gray-500 hover:bg-indigo-100 hover:text-indigo-600'
              }
            `}
            disabled={isProcessing || !connected}
          >
            {isRecording ? <MicOff size={20} /> : <Mic size={20} />}
          </motion.button>

          <div className="flex-1 relative">
            <input
              ref={inputRef}
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="اكتب أمراً أو سؤالاً..."
              className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 outline-none text-sm transition-all"
              disabled={!connected}
            />
          </div>

          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={handleSend}
            disabled={!inputText.trim() || !connected}
            className={`
              p-3 rounded-xl transition-all duration-200
              ${inputText.trim()
                ? 'bg-indigo-600 text-white shadow-md hover:bg-indigo-700'
                : 'bg-gray-100 text-gray-300 cursor-not-allowed'
              }
            `}
          >
            <Send size={20} />
          </motion.button>
        </div>

        {/* تلميح الأوامر */}
        <div className="mt-2 flex items-center gap-2 text-[10px] text-gray-400 flex-wrap">
          <span>💡 جرّب:</span>
          {[
            'اعرض المخزون المنخفض',
            'كم المنتجات القريبة انتهاءً؟',
            'احسب MKT لمستشعر X',
            'أنشئ مسودة تقرير مخزون',
            'اعرض تنبيهات الصلاحية'
          ].map((hint) => (
            <button
              key={hint}
              onClick={() => { setInputText(hint); inputRef.current?.focus(); }}
              className="px-2 py-0.5 rounded-full bg-gray-50 hover:bg-indigo-50 hover:text-indigo-500 transition-colors"
            >
              {hint}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

export default AIMode;
