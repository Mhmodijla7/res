# 🏥 Medical Lab Supply Platform

منصة رقمية متكاملة لتوريد المستلزمات والأجهزة المخبرية الطبية.

## 📦 المكونات

| المكوّن | التقنية | الوصف |
|---------|---------|-------|
| قاعدة البيانات | PostgreSQL 16 | 30+ جدول + FEFO triggers + MKT + Reports + Alerts |
| MCP Servers (×6) | Python + MCP SDK | Core, Catalog, Orders, Inventory (FEFO+MKT+Alerts+Reports), CRM, Compliance |
| Goose AI | Node.js + MCP Client | وكيل ذكي مع Human-in-the-Loop + Rate Limiting |
| Admin Cockpit | Next.js 14 + React | واجهة عائمة مع صوت + مسودات + تنبيهات + طابور عدم اتصال |
| API Gateway | Nginx | Reverse Proxy + Rate Limiting |

## 🚀 التشغيل السريع

### المتطلبات
- Docker + Docker Compose v2
- مفاتيح API: OpenAI أو Anthropic

### الخطوات

