-- =============================================================================
-- MEDICAL LAB SUPPLY PLATFORM — FULL DATABASE SCHEMA
-- Sprint 0: Foundation + LOINC/SNOMED + FEFO + Cold Chain MKT
-- PostgreSQL 16+
-- =============================================================================

-- أولاً: الامتدادات المطلوبة
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";       -- للبحث الضبابي

-- =============================================================================
-- ENUM TYPES
-- =============================================================================

CREATE TYPE order_status AS ENUM (
    'draft', 'pending_approval', 'approved', 'processing',
    'shipped', 'delivered', 'cancelled', 'returned'
);

CREATE TYPE audit_action AS ENUM (
    'create', 'read', 'update', 'delete',
    'login', 'logout', 'export', 'import',
    'approve', 'reject', 'override'
);

CREATE TYPE temperature_zone AS ENUM (
    'ambient',        -- 15-25°C
    'refrigerated',   -- 2-8°C
    'frozen',         -- -20°C
    'deep_frozen',    -- -80°C
    'cryogenic'       -- -196°C (liquid nitrogen)
);

CREATE TYPE human_approval_status AS ENUM (
    'pending', 'approved', 'rejected', 'expired', 'escalated'
);

CREATE TYPE batch_movement_type AS ENUM (
    'receive', 'consume', 'transfer', 'adjust',
    'return', 'destroy', 'recall', 'fefo_pick'
);

CREATE TYPE expiry_alert_level AS ENUM (
    'info',       -- 60 days
    'warning',    -- 30 days
    'critical',   -- 15 days
    'expired'     -- 0 days or past
);

-- =============================================================================
-- 1. USERS & AUTHENTICATION
-- =============================================================================

CREATE TABLE users (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email           VARCHAR(255) UNIQUE NOT NULL,
    password_hash   VARCHAR(255) NOT NULL,
    full_name       VARCHAR(200) NOT NULL,
    phone           VARCHAR(20),
    is_active       BOOLEAN DEFAULT true,
    is_verified     BOOLEAN DEFAULT false,
    mfa_secret      VARCHAR(100),
    last_login_at   TIMESTAMP WITH TIME ZONE,
    created_at      TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at      TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE roles (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name        VARCHAR(50) UNIQUE NOT NULL,
    description TEXT,
    permissions JSONB NOT NULL DEFAULT '{}',
    created_at  TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE user_roles (
    user_id     UUID REFERENCES users(id) ON DELETE CASCADE,
    role_id     UUID REFERENCES roles(id) ON DELETE CASCADE,
    granted_at  TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    granted_by  UUID REFERENCES users(id),
    PRIMARY KEY (user_id, role_id)
);

-- جدول الأدوار الافتراضية
INSERT INTO roles (name, description, permissions) VALUES
    ('super_admin', 'مدير النظام الكامل', '{"*": ["*"]}'),
    ('lab_manager', 'مدير المختبر', '{"products": ["read","create","update"], "orders": ["read","create","update","approve"], "inventory": ["read","update"], "reports": ["read","create","seal"], "alerts": ["read","acknowledge"]}'),
    ('quality_manager', 'مدير الجودة', '{"reports": ["read","create","seal","void"], "inventory": ["read"], "alerts": ["read","acknowledge"], "compliance": ["read","create"]}'),
    ('procurement', 'مسؤول المشتريات', '{"products": ["read"], "orders": ["read","create"], "suppliers": ["read","create","update"]}'),
    ('warehouse', 'مسؤول المستودع', '{"inventory": ["read","update"], "orders": ["read"], "shipments": ["read","create"]}'),
    ('viewer', 'مشاهد فقط', '{"products": ["read"], "orders": ["read"], "inventory": ["read"]}');

-- =============================================================================
-- 2. BRANDS & SUPPLIERS
-- =============================================================================

CREATE TABLE brands (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name                    VARCHAR(200) NOT NULL,
    country                 VARCHAR(100),
    website                 VARCHAR(300),
    logo_url                VARCHAR(500),
    is_authorized_distributor BOOLEAN DEFAULT false,
    certifications          JSONB DEFAULT '[]',
    created_at              TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE suppliers (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name            VARCHAR(200) NOT NULL,
    country         VARCHAR(100),
    city            VARCHAR(100),
    address         TEXT,
    contact_person  VARCHAR(100),
    email           VARCHAR(100),
    phone           VARCHAR(20),
    payment_terms_days INT DEFAULT 30,
    lead_time_days  INT DEFAULT 14,
    minimum_order_value DECIMAL(12,2) DEFAULT 0,
    currency        VARCHAR(3) DEFAULT 'SAR',
    is_active       BOOLEAN DEFAULT true,
    certifications  JSONB DEFAULT '[]',
    notes           TEXT,
    created_at      TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at      TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE brand_suppliers (
    brand_id    UUID REFERENCES brands(id) ON DELETE CASCADE,
    supplier_id UUID REFERENCES suppliers(id) ON DELETE CASCADE,
    is_primary  BOOLEAN DEFAULT false,
    PRIMARY KEY (brand_id, supplier_id)
);

-- =============================================================================
-- 3. CATEGORIES (ISO 15189 ALIGNED)
-- =============================================================================

CREATE TABLE categories (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name_ar     VARCHAR(200) NOT NULL,
    name_en     VARCHAR(200) NOT NULL,
    slug        VARCHAR(200) UNIQUE NOT NULL,
    parent_id   UUID REFERENCES categories(id),
    icon        VARCHAR(50),
    description_ar TEXT,
    description_en TEXT,
    iso_reference VARCHAR(100),   -- المرجع في ISO 15189
    clsi_reference VARCHAR(100), -- المرجع في CLSI
    sort_order  INT DEFAULT 0,
    is_active   BOOLEAN DEFAULT true,
    created_at  TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- بيانات التصنيفات الرئيسية — 16 قسماً مخبرياً
INSERT INTO categories (name_ar, name_en, slug, iso_reference, sort_order) VALUES
    ('الكيمياء الحيوية', 'Clinical Chemistry', 'clinical-chemistry', 'ISO 15189 §7.4', 1),
    ('الهيماتولوجيا', 'Hematology', 'hematology', 'ISO 15189 §7.4', 2),
    ('المناعة المخبرية', 'Clinical Immunology', 'clinical-immunology', 'ISO 15189 §7.4', 3),
    ('الميكروبيولوجي', 'Microbiology', 'microbiology', 'ISO 15189 §7.4', 4),
    ('علم الفيروسات', 'Virology', 'virology', 'ISO 15189 §7.4', 5),
    ('علم الطفيليات', 'Parasitology', 'parasitology', 'ISO 15189 §7.4', 6),
    ('علم الفطريات', 'Mycology', 'mycology', 'ISO 15189 §7.4', 7),
    ('علم الأمراض التشريحي', 'Histopathology', 'histopathology', 'ISO 15189 §7.4', 8),
    ('علم الأمراض الخلويا', 'Cytopathology', 'cytopathology', 'ISO 15189 §7.4', 9),
    ('بنك الدم', 'Blood Banking / Transfusion', 'blood-banking', 'ISO 15189 §7.4', 10),
    ('علم الوراثة الجزيئي', 'Molecular Diagnostics', 'molecular-diagnostics', 'ISO 15189 §7.4', 11),
    ('علم الأدوية', 'Therapeutic Drug Monitoring', 'tdm', 'ISO 15189 §7.4', 12),
    ('السموم السريرية', 'Clinical Toxicology', 'toxicology', 'ISO 15189 §7.4', 13),
    ('الهرمونات', 'Endocrinology / Hormones', 'endocrinology', 'ISO 15189 §7.4', 14),
    ('تحليل البول', 'Urinalysis', 'urinalysis', 'ISO 15189 §7.4', 15),
    ('ضبط الجودة والمعايرة', 'Quality Control & Calibration', 'qc-calibration', 'ISO 15189 §7.3', 16);

-- الفئات الفرعية (أمثلة لقسم الكيمياء الحيوية)
INSERT INTO categories (name_ar, name_en, slug, parent_id, iso_reference) VALUES
    ('وظائف الكبد', 'Liver Function Tests', 'liver-function',
        (SELECT id FROM categories WHERE slug = 'clinical-chemistry'), 'ISO 15189 §7.4.2'),
    ('وظائف الكلى', 'Renal Function Tests', 'renal-function',
        (SELECT id FROM categories WHERE slug = 'clinical-chemistry'), 'ISO 15189 §7.4.2'),
    ('الدهون والشحوم', 'Lipid Profile', 'lipid-profile',
        (SELECT id FROM categories WHERE slug = 'clinical-chemistry'), 'ISO 15189 §7.4.2'),
    ('الإنزيمات', 'Enzymes', 'enzymes',
        (SELECT id FROM categories WHERE slug = 'clinical-chemistry'), 'ISO 15189 §7.4.2'),
    ('الإلكتروليتات', 'Electrolytes', 'electrolytes',
        (SELECT id FROM categories WHERE slug = 'clinical-chemistry'), 'ISO 15189 §7.4.2'),
    ('البروتينات', 'Proteins', 'proteins',
        (SELECT id FROM categories WHERE slug = 'clinical-chemistry'), 'ISO 15189 §7.4.2'),
    ('السكريات', 'Glucose / Diabetes', 'glucose-diabetes',
        (SELECT id FROM categories WHERE slug = 'clinical-chemistry'), 'ISO 15189 §7.4.2'),
    ('الغازات الدموية', 'Blood Gas Analysis', 'blood-gas',
        (SELECT id FROM categories WHERE slug = 'clinical-chemistry'), 'ISO 15189 §7.4.2');

-- =============================================================================
-- 4. PRODUCTS (مع حقول LOINC + SNOMED + FEFO)
-- =============================================================================

CREATE TABLE products (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    sku                 VARCHAR(50) UNIQUE NOT NULL,
    name_ar             VARCHAR(300) NOT NULL,
    name_en             VARCHAR(300) NOT NULL,
    description_ar      TEXT,
    description_en      TEXT,

    -- التصنيف
    category_id         UUID REFERENCES categories(id),
    brand_id            UUID REFERENCES brands(id),
    product_type        VARCHAR(30) DEFAULT 'reagent',
        -- 'reagent', 'instrument', 'consumable', 'control', 'calibrator', 'kit'

    -- الترميز الطبي الدولي
    loinc_code          VARCHAR(20),
    loinc_long_name     VARCHAR(500),
    snomed_code         VARCHAR(20),
    snomed_fsn          VARCHAR(500),
    loinc_class         VARCHAR(100),

    -- التسعير
    unit_price          DECIMAL(12,2) NOT NULL,
    cost_price          DECIMAL(12,2),
    currency            VARCHAR(3) DEFAULT 'SAR',
    tax_rate            DECIMAL(5,2) DEFAULT 15.00,

    -- المخزون
    stock_quantity      INT DEFAULT 0,
    reserved_quantity   INT DEFAULT 0,
    min_stock_level     INT DEFAULT 10,
    reorder_quantity    INT DEFAULT 50,
    unit_of_measure     VARCHAR(30) DEFAULT 'piece',

    -- المنتج الفيزيائي
    barcode             VARCHAR(50),
    cas_number          VARCHAR(20),
    weight_grams        DECIMAL(8,2),
    dimensions_json     JSONB,

    -- شروط التخزين
    storage_zone        temperature_zone DEFAULT 'ambient',
    storage_temp_min_c  DECIMAL(5,2),
    storage_temp_max_c  DECIMAL(5,2),
    storage_light_req   VARCHAR(30) DEFAULT 'none',
    storage_humidity_max INT,

    -- إدارة الصلاحية FEFO
    shelf_life_months   INT,
    requires_fefo       BOOLEAN DEFAULT true,
    min_remaining_shelf_pct DECIMAL(5,2) DEFAULT 10.00,

    -- التنظيمي
    is_hazardous        BOOLEAN DEFAULT false,
    hazard_class        VARCHAR(30),
    regulatory_status   VARCHAR(50),
    registration_number VARCHAR(100),
    requires_cold_chain BOOLEAN DEFAULT false,
    is_controlled       BOOLEAN DEFAULT false,

    -- المرفقات
    images              JSONB DEFAULT '[]',
    attachments         JSONB DEFAULT '[]',
    specifications      JSONB DEFAULT '{}',
    safety_data_sheet   VARCHAR(500),

    -- الحالة
    is_active           BOOLEAN DEFAULT true,
    is_featured         BOOLEAN DEFAULT false,
    created_by          UUID REFERENCES users(id),
    created_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- فهرس على أكواد LOINC للبحث السريع
CREATE INDEX idx_products_loinc_code ON products(loinc_code) WHERE loinc_code IS NOT NULL;
CREATE INDEX idx_products_snomed_code ON products(snomed_code) WHERE snomed_code IS NOT NULL;
CREATE INDEX idx_products_category ON products(category_id);
CREATE INDEX idx_products_storage_zone ON products(storage_zone);
CREATE INDEX idx_products_fefo ON products(requires_fefo) WHERE requires_fefo = true;

-- فهرس بحث نصي
CREATE INDEX idx_products_search_ar ON products USING gin(name_ar gin_trgm_ops);
CREATE INDEX idx_products_search_en ON products USING gin(name_en gin_trgm_ops);

-- =============================================================================
-- 5. PRODUCT BATCHES (FEFO Core)
-- =============================================================================

CREATE TABLE product_batches (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    product_id          UUID REFERENCES products(id) ON DELETE CASCADE,
    batch_number        VARCHAR(100) NOT NULL,
    lot_number          VARCHAR(100),

    -- الكمية
    initial_quantity    INT NOT NULL,
    current_quantity    INT NOT NULL,

    -- الصلاحية FEFO core
    manufacturing_date  DATE,
    expiry_date         DATE NOT NULL,
    remaining_shelf_pct DECIMAL(5,2),

    -- سلسلة التبريد
    received_at_temp_c  DECIMAL(5,2),
    storage_zone        temperature_zone DEFAULT 'ambient',

    -- التكلفة
    unit_cost           DECIMAL(12,2),

    -- التتبع
    supplier_id         UUID REFERENCES suppliers(id),
    purchase_order_ref  VARCHAR(100),
    certificate_of_analysis VARCHAR(500),
    is_quarantine       BOOLEAN DEFAULT false,
    is_recalled         BOOLEAN DEFAULT false,

    -- ★ التحقق من صحة التاريخ (Schema Validation)
    CONSTRAINT chk_expiry_after_mfg CHECK (
        manufacturing_date IS NULL OR expiry_date > manufacturing_date
    ),
    CONSTRAINT chk_future_expiry CHECK (
        expiry_date > '2000-01-01'::DATE
    ),

    created_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW(),

    UNIQUE (product_id, batch_number)
);

-- فهرس FEFO: الأقرب انتهاءً أولاً
CREATE INDEX idx_batches_fefo ON product_batches(product_id, expiry_date ASC, current_quantity DESC)
    WHERE current_quantity > 0 AND is_quarantine = false AND is_recalled = false;

-- فهرس الانتهاء القريب للتنبيهات
CREATE INDEX idx_batches_expiring_soon ON product_batches(expiry_date)
    WHERE current_quantity > 0;

-- =============================================================================
-- 6. BATCH MOVEMENTS (سلسلة التتبع الكاملة)
-- =============================================================================

CREATE TABLE batch_movements (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    batch_id        UUID REFERENCES product_batches(id),
    product_id      UUID REFERENCES products(id),
    movement_type   batch_movement_type NOT NULL,
    quantity         INT NOT NULL,
    reference_type  VARCHAR(30),
    reference_id    UUID,
    from_location   VARCHAR(100),
    to_location     VARCHAR(100),
    temperature_at_move DECIMAL(5,2),
    notes           TEXT,
    performed_by    UUID REFERENCES users(id),
    created_at      TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_movements_batch ON batch_movements(batch_id, created_at DESC);
CREATE INDEX idx_movements_product ON batch_movements(product_id, created_at DESC);

-- =============================================================================
-- 7. FEFO FUNCTIONS & TRIGGERS
-- =============================================================================

-- دالة حساب النسبة المتبقية من الصلاحية
CREATE OR REPLACE FUNCTION calculate_remaining_shelf_pct()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.expiry_date IS NOT NULL AND NEW.manufacturing_date IS NOT NULL THEN
        DECLARE
            total_days  INT;
            remain_days INT;
        BEGIN
            total_days  := (NEW.expiry_date - NEW.manufacturing_date);
            remain_days := (NEW.expiry_date - CURRENT_DATE);

            IF total_days > 0 THEN
                NEW.remaining_shelf_pct := GREATEST(0, (remain_days::DECIMAL / total_days) * 100);
            ELSE
                NEW.remaining_shelf_pct := 0;
            END IF;
        END;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_calculate_shelf_pct
    BEFORE INSERT OR UPDATE OF expiry_date, manufacturing_date
    ON product_batches
    FOR EACH ROW
    EXECUTE FUNCTION calculate_remaining_shelf_pct();

-- دالة FEFO: اقتراح أقرب دفعة منتهية الصلاحية للاستهلاك
CREATE OR REPLACE FUNCTION fefo_pick_batch(
    p_product_id UUID,
    p_quantity   INT
) RETURNS TABLE (
    batch_id        UUID,
    batch_number    VARCHAR,
    expiry_date     DATE,
    available_qty   INT,
    pick_qty        INT,
    remaining_shelf DECIMAL
) AS $$
DECLARE
    remaining INT := p_quantity;
    rec RECORD;
BEGIN
    FOR rec IN
        SELECT
            pb.id,
            pb.batch_number,
            pb.expiry_date,
            pb.current_quantity,
            pb.remaining_shelf_pct
        FROM product_batches pb
        WHERE pb.product_id = p_product_id
          AND pb.current_quantity > 0
          AND pb.is_quarantine = false
          AND pb.is_recalled = false
          AND pb.expiry_date > CURRENT_DATE
        ORDER BY pb.expiry_date ASC, pb.current_quantity ASC
    LOOP
        IF remaining <= 0 THEN
            EXIT;
        END IF;

        batch_id        := rec.id;
        batch_number    := rec.batch_number;
        expiry_date     := rec.expiry_date;
        available_qty   := rec.current_quantity;
        remaining_shelf := rec.remaining_shelf_pct;

        IF rec.current_quantity >= remaining THEN
            pick_qty := remaining;
            remaining := 0;
        ELSE
            pick_qty := rec.current_quantity;
            remaining := remaining - rec.current_quantity;
        END IF;

        RETURN NEXT;
    END LOOP;

    IF remaining > 0 THEN
        RAISE EXCEPTION 'FEFO: Insufficient stock for product %. Missing: % units', p_product_id, remaining;
    END IF;
END;
$$ LANGUAGE plpgsql;

-- دالة تنفيذ سحب FEFO (تحديث الكميات + تسجيل الحركة)
CREATE OR REPLACE FUNCTION execute_fefo_pick(
    p_product_id UUID,
    p_quantity   INT,
    p_user_id    UUID,
    p_ref_type   VARCHAR DEFAULT 'order',
    p_ref_id     UUID DEFAULT NULL
) RETURNS JSONB AS $$
DECLARE
    rec RECORD;
    remaining INT := p_quantity;
    picked JSONB := '[]'::JSONB;
BEGIN
    FOR rec IN SELECT * FROM fefo_pick_batch(p_product_id, p_quantity)
    LOOP
        UPDATE product_batches
        SET current_quantity = current_quantity - rec.pick_qty,
            updated_at = NOW()
        WHERE id = rec.batch_id;

        UPDATE products
        SET stock_quantity = stock_quantity - rec.pick_qty,
            updated_at = NOW()
        WHERE id = p_product_id;

        INSERT INTO batch_movements (batch_id, product_id, movement_type, quantity, reference_type, reference_id, performed_by)
        VALUES (rec.batch_id, p_product_id, 'fefo_pick', -rec.pick_qty, p_ref_type, p_ref_id, p_user_id);

        picked := picked || jsonb_build_object(
            'batch_id', rec.batch_id,
            'batch_number', rec.batch_number,
            'expiry_date', rec.expiry_date,
            'quantity', rec.pick_qty
        );

        remaining := remaining - rec.pick_qty;
    END LOOP;

    RETURN jsonb_build_object('success', true, 'picked', picked, 'total', p_quantity);
END;
$$ LANGUAGE plpgsql;

-- =============================================================================
-- 8. COLD CHAIN MONITORING (مع MKT)
-- =============================================================================

CREATE TABLE cold_chain_readings (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    sensor_id       VARCHAR(100) NOT NULL,
    location        VARCHAR(200),
    zone            temperature_zone,
    temperature_c   DECIMAL(5,2) NOT NULL,
    humidity_pct    DECIMAL(5,2),
    is_alarm        BOOLEAN DEFAULT false,
    alarm_reason    VARCHAR(200),
    recorded_at     TIMESTAMP WITH TIME ZONE NOT NULL,
    created_at      TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_ccr_sensor_time ON cold_chain_readings(sensor_id, recorded_at DESC);
CREATE INDEX idx_ccr_alarms ON cold_chain_readings(is_alarm, recorded_at DESC) WHERE is_alarm = true;

-- جدول MKT
CREATE TABLE cold_chain_mkt (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    sensor_id       VARCHAR(100) NOT NULL,
    location        VARCHAR(200),
    zone            temperature_zone,
    period_start    TIMESTAMP WITH TIME ZONE NOT NULL,
    period_end      TIMESTAMP WITH TIME ZONE NOT NULL,
    num_readings    INT NOT NULL,
    mkt_value_c     DECIMAL(5,2) NOT NULL,
    min_temp_c      DECIMAL(5,2),
    max_temp_c      DECIMAL(5,2),
    avg_temp_c      DECIMAL(5,2),
    std_deviation   DECIMAL(5,2),
    is_compliant    BOOLEAN NOT NULL,
    zone_min_c      DECIMAL(5,2),
    zone_max_c      DECIMAL(5,2),
    excursion_count INT DEFAULT 0,
    calculated_at   TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_mkt_sensor ON cold_chain_mkt(sensor_id, period_end DESC);
CREATE INDEX idx_mkt_non_compliant ON cold_chain_mkt(is_compliant) WHERE is_compliant = false;

-- دالة حساب MKT
CREATE OR REPLACE FUNCTION calculate_mkt(
    p_sensor_id  VARCHAR,
    p_start      TIMESTAMP WITH TIME ZONE,
    p_end        TIMESTAMP WITH TIME ZONE
) RETURNS TABLE (
    mkt_value_c     DECIMAL,
    min_temp_c      DECIMAL,
    max_temp_c      DECIMAL,
    avg_temp_c      DECIMAL,
    std_dev         DECIMAL,
    num_readings    INT,
    excursion_count INT
) AS $$
DECLARE
    R CONSTANT DECIMAL := 8.314472;
    delta_h CONSTANT DECIMAL := 83144.72;
    rec RECORD;
    sum_exp DECIMAL := 0;
    cnt INT := 0;
    t_min DECIMAL := 999;
    t_max DECIMAL := -999;
    t_sum DECIMAL := 0;
    t_sum_sq DECIMAL := 0;
    excursions INT := 0;
BEGIN
    FOR rec IN
        SELECT temperature_c
        FROM cold_chain_readings
        WHERE sensor_id = p_sensor_id
          AND recorded_at BETWEEN p_start AND p_end
        ORDER BY recorded_at
    LOOP
        DECLARE
            t_kelvin DECIMAL;
            exp_term DECIMAL;
        BEGIN
            t_kelvin := rec.temperature_c + 273.15;

            IF t_kelvin > 0 THEN
                exp_term := EXP(-delta_h / (R * t_kelvin));
                sum_exp := sum_exp + exp_term;
            END IF;

            cnt := cnt + 1;
            t_sum := t_sum + rec.temperature_c;
            t_sum_sq := t_sum_sq + (rec.temperature_c * rec.temperature_c);

            IF rec.temperature_c < t_min THEN t_min := rec.temperature_c; END IF;
            IF rec.temperature_c > t_max THEN t_max := rec.temperature_c; END IF;
        END;
    END LOOP;

    IF cnt > 0 THEN
        DECLARE
            mean_exp DECIMAL;
            ln_mean  DECIMAL;
            mkt_k    DECIMAL;
            mean_t   DECIMAL;
            variance DECIMAL;
        BEGIN
            mean_exp := sum_exp / cnt;
            ln_mean  := LN(mean_exp);
            mkt_k    := -delta_h / (R * ln_mean);
            mkt_value_c := mkt_k - 273.15;
            mean_t   := t_sum / cnt;
            avg_temp_c := mean_t;
            min_temp_c := t_min;
            max_temp_c := t_max;
            num_readings := cnt;

            variance := (t_sum_sq / cnt) - (mean_t * mean_t);
            IF variance > 0 THEN
                std_dev := SQRT(variance);
            ELSE
                std_dev := 0;
            END IF;

            SELECT COUNT(*) INTO excursions
            FROM cold_chain_readings
            WHERE sensor_id = p_sensor_id
              AND recorded_at BETWEEN p_start AND p_end
              AND ABS(temperature_c - mkt_value_c) > 2.0;

            excursion_count := excursions;
        END;
    ELSE
        mkt_value_c := NULL;
        min_temp_c := NULL;
        max_temp_c := NULL;
        avg_temp_c := NULL;
        std_dev := NULL;
        num_readings := 0;
        excursion_count := 0;
    END IF;

    RETURN NEXT;
END;
$$ LANGUAGE plpgsql;

-- =============================================================================
-- 9. CUSTOMERS
-- =============================================================================

CREATE TABLE customers (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    type                VARCHAR(30) NOT NULL DEFAULT 'lab',
    name                VARCHAR(300) NOT NULL,
    name_ar             VARCHAR(300),
    license_number      VARCHAR(100),
    moh_facility_id     VARCHAR(50),
    contact_person      VARCHAR(100),
    email               VARCHAR(100),
    phone               VARCHAR(20),
    secondary_phone     VARCHAR(20),
    address             JSONB,
    latitude            DECIMAL(10,7),
    longitude           DECIMAL(10,7),
    credit_limit        DECIMAL(12,2) DEFAULT 0,
    current_balance     DECIMAL(12,2) DEFAULT 0,
    payment_terms_days  INT DEFAULT 30,
    discount_pct        DECIMAL(5,2) DEFAULT 0,
    is_verified         BOOLEAN DEFAULT false,
    verified_at         TIMESTAMP WITH TIME ZONE,
    verified_by         UUID REFERENCES users(id),
    tier                VARCHAR(20) DEFAULT 'standard',
    tags                JSONB DEFAULT '[]',
    notes               TEXT,
    created_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- =============================================================================
-- 10. ORDERS
-- =============================================================================

CREATE TABLE orders (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    order_number        VARCHAR(20) UNIQUE NOT NULL,
    customer_id         UUID REFERENCES customers(id),
    status              order_status DEFAULT 'draft',
    subtotal            DECIMAL(12,2) DEFAULT 0,
    discount_amount     DECIMAL(12,2) DEFAULT 0,
    tax_amount          DECIMAL(12,2) DEFAULT 0,
    shipping_amount     DECIMAL(12,2) DEFAULT 0,
    total_amount        DECIMAL(12,2) DEFAULT 0,
    shipping_address    JSONB,
    shipping_method     VARCHAR(50),
    tracking_number     VARCHAR(100),
    estimated_delivery  DATE,
    fefo_enforced       BOOLEAN DEFAULT true,
    fefo_override       BOOLEAN DEFAULT false,
    fefo_override_reason TEXT,
    fefo_override_by    UUID REFERENCES users(id),
    requires_approval   BOOLEAN DEFAULT false,
    approval_status     human_approval_status DEFAULT 'pending',
    approved_by         UUID REFERENCES users(id),
    approved_at         TIMESTAMP WITH TIME ZONE,
    approval_notes      TEXT,
    hash_chain_prev     VARCHAR(64),
    hash_chain_current  VARCHAR(64),
    notes               TEXT,
    internal_notes      TEXT,
    created_by          UUID REFERENCES users(id),
    created_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE order_items (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    order_id        UUID REFERENCES orders(id) ON DELETE CASCADE,
    product_id      UUID REFERENCES products(id),
    batch_id        UUID REFERENCES product_batches(id),
    batch_number    VARCHAR(100),
    batch_expiry    DATE,
    remaining_shelf_pct DECIMAL(5,2),
    quantity        INT NOT NULL,
    unit_price      DECIMAL(12,2),
    discount_pct    DECIMAL(5,2) DEFAULT 0,
    tax_amount      DECIMAL(12,2) DEFAULT 0,
    total_price     DECIMAL(12,2),
    loinc_code      VARCHAR(20),
    snomed_code     VARCHAR(20),
    notes           TEXT,
    created_at      TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- =============================================================================
-- 11. QUOTATIONS
-- =============================================================================

CREATE TABLE quotations (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    quotation_number    VARCHAR(20) UNIQUE NOT NULL,
    customer_id         UUID REFERENCES customers(id),
    status              VARCHAR(20) DEFAULT 'draft',
    valid_until         DATE,
    subtotal            DECIMAL(12,2) DEFAULT 0,
    discount_pct        DECIMAL(5,2) DEFAULT 0,
    tax_amount          DECIMAL(12,2) DEFAULT 0,
    total_amount        DECIMAL(12,2) DEFAULT 0,
    terms_conditions    TEXT,
    notes               TEXT,
    created_by          UUID REFERENCES users(id),
    created_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE quotation_items (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    quotation_id    UUID REFERENCES quotations(id) ON DELETE CASCADE,
    product_id      UUID REFERENCES products(id),
    quantity        INT NOT NULL,
    unit_price      DECIMAL(12,2),
    discount_pct    DECIMAL(5,2) DEFAULT 0,
    total_price     DECIMAL(12,2),
    notes           TEXT
);

-- =============================================================================
-- 12. INVENTORY TRANSACTIONS
-- =============================================================================

CREATE TABLE inventory_transactions (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    product_id      UUID REFERENCES products(id),
    batch_id        UUID REFERENCES product_batches(id),
    type            VARCHAR(30) NOT NULL,
    quantity         INT NOT NULL,
    unit_cost       DECIMAL(12,2),
    reference_type  VARCHAR(30),
    reference_id    UUID,
    from_location   VARCHAR(100),
    to_location     VARCHAR(100),
    reason          TEXT,
    performed_by    UUID REFERENCES users(id),
    created_at      TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- =============================================================================
-- 13. PURCHASE ORDERS
-- =============================================================================

CREATE TABLE purchase_orders (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    po_number       VARCHAR(20) UNIQUE NOT NULL,
    supplier_id     UUID REFERENCES suppliers(id),
    status          VARCHAR(20) DEFAULT 'draft',
    total_amount    DECIMAL(12,2) DEFAULT 0,
    currency        VARCHAR(3) DEFAULT 'SAR',
    expected_date   DATE,
    received_date   DATE,
    notes           TEXT,
    created_by      UUID REFERENCES users(id),
    created_at      TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at      TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE purchase_order_items (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    po_id           UUID REFERENCES purchase_orders(id) ON DELETE CASCADE,
    product_id      UUID REFERENCES products(id),
    quantity_ordered INT NOT NULL,
    quantity_received INT DEFAULT 0,
    unit_cost       DECIMAL(12,2),
    total_cost      DECIMAL(12,2),
    batch_number    VARCHAR(100),
    expiry_date     DATE
);

-- =============================================================================
-- 14. HUMAN-IN-THE-LOOP APPROVALS
-- =============================================================================

CREATE TABLE approval_requests (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    request_type        VARCHAR(50) NOT NULL,
    entity_type         VARCHAR(50) NOT NULL,
    entity_id           UUID NOT NULL,
    requested_by        VARCHAR(50),
    requester_name      VARCHAR(200),
    action_description  TEXT NOT NULL,
    action_params       JSONB NOT NULL,
    status              human_approval_status DEFAULT 'pending',
    assigned_to         UUID REFERENCES users(id),
    approved_by         UUID REFERENCES users(id),
    approved_at         TIMESTAMP WITH TIME ZONE,
    rejection_reason    TEXT,
    expires_at          TIMESTAMP WITH TIME ZONE DEFAULT (NOW() + INTERVAL '24 hours'),
    hash_chain          VARCHAR(64),
    created_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_approvals_pending ON approval_requests(status, assigned_to)
    WHERE status = 'pending';
CREATE INDEX idx_approvals_entity ON approval_requests(entity_type, entity_id);

-- =============================================================================
-- 15. AUDIT LOG (سلسلة تدقيق غير قابلة للتزوير)
-- =============================================================================

CREATE TABLE audit_log (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    action          audit_action NOT NULL,
    entity_type     VARCHAR(50) NOT NULL,
    entity_id       UUID,
    actor_type      VARCHAR(20) NOT NULL,
    actor_id        VARCHAR(100) NOT NULL,
    actor_name      VARCHAR(200),
    old_values      JSONB,
    new_values      JSONB,
    ip_address      INET,
    user_agent      TEXT,
    mcp_server      VARCHAR(50),
    mcp_tool        VARCHAR(50),
    session_id      VARCHAR(100),
    hash_prev       VARCHAR(64),
    hash_current    VARCHAR(64) NOT NULL,
    created_at      TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_audit_entity ON audit_log(entity_type, entity_id, created_at DESC);
CREATE INDEX idx_audit_actor ON audit_log(actor_type, actor_id, created_at DESC);
CREATE INDEX idx_audit_time ON audit_log(created_at DESC);

-- دالة حساب الـ hash chain
CREATE OR REPLACE FUNCTION compute_audit_hash()
RETURNS TRIGGER AS $$
DECLARE
    prev_hash VARCHAR(64);
    payload TEXT;
BEGIN
    SELECT hash_current INTO prev_hash
    FROM audit_log
    ORDER BY created_at DESC
    LIMIT 1;

    IF prev_hash IS NULL THEN
        prev_hash := '0000000000000000000000000000000000000000000000000000000000000000';
    END IF;

    NEW.hash_prev := prev_hash;

    payload := COALESCE(NEW.action::TEXT, '') ||
               COALESCE(NEW.entity_type, '') ||
               COALESCE(NEW.entity_id::TEXT, '') ||
               COALESCE(NEW.actor_id, '') ||
               prev_hash ||
               COALESCE(NEW.created_at::TEXT, '');

    NEW.hash_current := encode(digest(payload, 'sha256'), 'hex');

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_audit_hash_chain
    BEFORE INSERT ON audit_log
    FOR EACH ROW
    EXECUTE FUNCTION compute_audit_hash();

-- =============================================================================
-- 16. AI CHAT SESSIONS
-- =============================================================================

CREATE TABLE ai_chat_sessions (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID REFERENCES users(id),
    session_type    VARCHAR(30) DEFAULT 'text',
    mcp_server_used VARCHAR(50),
    tools_called    JSONB DEFAULT '[]',
    approval_count  INT DEFAULT 0,
    started_at      TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    ended_at        TIMESTAMP WITH TIME ZONE
);

CREATE TABLE ai_chat_messages (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    session_id      UUID REFERENCES ai_chat_sessions(id) ON DELETE CASCADE,
    role            VARCHAR(20) NOT NULL,
    content         TEXT NOT NULL,
    tool_calls      JSONB,
    tool_results    JSONB,
    voice_input     BOOLEAN DEFAULT false,
    whisper_transcript TEXT,
    draft_action    JSONB,
    draft_approved  BOOLEAN,
    created_at      TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- =============================================================================
-- 17. MCP TOOL REGISTRY
-- =============================================================================

CREATE TABLE mcp_tool_registry (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    server_name     VARCHAR(50) NOT NULL,
    tool_name       VARCHAR(100) NOT NULL,
    description     TEXT,
    parameters_schema JSONB,
    requires_human_approval BOOLEAN DEFAULT false,
    min_approval_role       VARCHAR(50) DEFAULT 'super_admin',
    rate_limit_per_min      INT DEFAULT 60,
    rate_limit_per_hour     INT DEFAULT 500,
    is_sensitive            BOOLEAN DEFAULT false,
    is_active               BOOLEAN DEFAULT true,
    created_at      TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(server_name, tool_name)
);

INSERT INTO mcp_tool_registry (server_name, tool_name, description, requires_human_approval, min_approval_role, is_sensitive) VALUES
    ('inventory', 'adjust_stock', 'تعديل كمية المخزون يدوياً', true, 'lab_manager', true),
    ('inventory', 'destroy_batch', 'تدمير دفعة منتهية الصلاحية', true, 'super_admin', true),
    ('orders', 'create_order', 'إنشاء طلب جديد', false, 'lab_manager', false),
    ('orders', 'approve_order', 'الموافقة على طلب يتجاوز الحد', true, 'super_admin', true),
    ('catalog', 'update_price', 'تحديث سعر منتج', true, 'super_admin', true),
    ('catalog', 'delete_product', 'حذف منتج من الكتالوج', true, 'super_admin', true),
    ('crm', 'send_bulk_email', 'إرسال بريد جماعي', true, 'super_admin', true),
    ('compliance', 'issue_recall', 'إصدار استدعاء سلامة', true, 'super_admin', true),
    ('compliance', 'write_off_batch', 'شطب دفعة كاملة', true, 'super_admin', true),
    ('inventory', 'seal_report', 'ختم تقرير رقمياً', true, 'quality_manager', true),
    ('inventory', 'void_report', 'إلغاء تقرير مختوم', true, 'super_admin', true);

-- =============================================================================
-- 18. EXISTING VIEWS
-- =============================================================================

CREATE VIEW v_low_stock AS
SELECT
    p.id, p.sku, p.name_ar, p.name_en,
    p.stock_quantity, p.min_stock_level, p.reorder_quantity,
    p.storage_zone, p.requires_cold_chain,
    c.name_ar AS category_name,
    b.name AS brand_name
FROM products p
LEFT JOIN categories c ON p.category_id = c.id
LEFT JOIN brands b ON p.brand_id = b.id
WHERE p.stock_quantity <= p.min_stock_level
  AND p.is_active = true
ORDER BY (p.stock_quantity::DECIMAL / NULLIF(p.min_stock_level, 0)) ASC;

CREATE VIEW v_expiring_batches AS
SELECT
    pb.id AS batch_id, pb.batch_number, pb.expiry_date,
    pb.current_quantity, pb.remaining_shelf_pct,
    p.sku, p.name_ar, p.name_en,
    p.min_remaining_shelf_pct,
    CASE
        WHEN pb.expiry_date <= CURRENT_DATE THEN 'EXPIRED'
        WHEN pb.remaining_shelf_pct <= p.min_remaining_shelf_pct THEN 'CRITICAL'
        WHEN pb.expiry_date <= CURRENT_DATE + INTERVAL '30 days' THEN 'WARNING'
        ELSE 'OK'
    END AS expiry_status
FROM product_batches pb
JOIN products p ON pb.product_id = p.id
WHERE pb.current_quantity > 0
  AND p.requires_fefo = true
ORDER BY pb.expiry_date ASC;

CREATE VIEW v_pending_approvals AS
SELECT
    ar.id, ar.request_type, ar.entity_type, ar.entity_id,
    ar.requested_by, ar.action_description, ar.action_params,
    ar.status, ar.expires_at,
    u.full_name AS assigned_to_name,
    ar.created_at
FROM approval_requests ar
LEFT JOIN users u ON ar.assigned_to = u.id
WHERE ar.status = 'pending'
  AND ar.expires_at > NOW()
ORDER BY ar.created_at ASC;

CREATE VIEW v_cold_chain_mkt_summary AS
SELECT
    zone, location, mkt_value_c, min_temp_c, max_temp_c,
    excursion_count, is_compliant, period_end
FROM cold_chain_mkt
WHERE id IN (
    SELECT MAX(id) FROM cold_chain_mkt GROUP BY sensor_id
)
ORDER BY zone, location;

-- =============================================================================
-- 19. EXISTING INDEXES
-- =============================================================================

CREATE INDEX idx_orders_customer ON orders(customer_id, created_at DESC);
CREATE INDEX idx_orders_status ON orders(status);
CREATE INDEX idx_customers_type ON customers(type);
CREATE INDEX idx_customers_tier ON customers(tier);
CREATE INDEX idx_quotations_customer ON quotations(customer_id);

-- =============================================================================
-- 20. REPORTS SYSTEM (Draft Mode + Versioning + Digital Seal)
-- =============================================================================

CREATE TABLE report_drafts (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    draft_type          VARCHAR(50) NOT NULL,
        -- 'inventory_summary', 'expiry_report', 'cold_chain', 'fefo_compliance', 'custom'
    title               VARCHAR(300) NOT NULL,
    parameters          JSONB NOT NULL DEFAULT '{}',
        -- {"date_range": {...}, "categories": [...], "zones": [...]}
    inventory_snapshot  JSONB,
        -- لقطة المخزون وقت إنشاء المسودة
    computed_stats      JSONB,
        -- {"expired": 5, "near_expiry": 12, "total_items": 500, ...}
    generated_by_ai     BOOLEAN DEFAULT false,
    ai_model            VARCHAR(100),
    ai_prompt_used      TEXT,
    status              VARCHAR(20) DEFAULT 'draft',
        -- 'draft', 'under_review', 'approved', 'rejected', 'sealed'
    created_by          UUID REFERENCES users(id),
    reviewed_by         UUID REFERENCES users(id),
    reviewed_at         TIMESTAMP WITH TIME ZONE,
    review_notes        TEXT,
    hash_draft          VARCHAR(64),  -- SHA-256 of draft content for integrity
    created_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE reports (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    report_number       VARCHAR(30) UNIQUE NOT NULL,
        -- LAB-RPT-2024-0001
    draft_id            UUID REFERENCES report_drafts(id),
    title               VARCHAR(300) NOT NULL,
    report_type         VARCHAR(50) NOT NULL,
    content             JSONB NOT NULL,      -- المحتوى النهائي
    metadata            JSONB DEFAULT '{}',  -- معلومات المختبر، تاريخ التوليد
    version             INT DEFAULT 1,
    is_latest           BOOLEAN DEFAULT true,
    status              VARCHAR(20) DEFAULT 'sealed',
        -- 'sealed', 'voided'
    sealed_by           UUID REFERENCES users(id),
    sealed_at           TIMESTAMP WITH TIME ZONE,
    digital_seal        VARCHAR(64),  -- SHA-256 hash = الختم الرقمي
    qr_code_data        TEXT,          -- بيانات QR للتحقق
    pdf_url             VARCHAR(500),  -- رابط PDF المُنشأ
    voided_by           UUID REFERENCES users(id),
    voided_at           TIMESTAMP WITH TIME ZONE,
    void_reason         TEXT,
    created_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE report_versions (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    report_id           UUID REFERENCES reports(id) ON DELETE CASCADE,
    version_number      INT NOT NULL,
    content             JSONB NOT NULL,
    digital_seal        VARCHAR(64),
    change_description  TEXT,
    created_by          UUID REFERENCES users(id),
    created_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- =============================================================================
-- 21. EXPIRY ALERT SYSTEM ★ Active Notifications
-- =============================================================================

CREATE TABLE expiry_alerts (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    product_id          UUID REFERENCES products(id),
    batch_id            UUID REFERENCES product_batches(id),
    alert_level         expiry_alert_level NOT NULL,
    days_until_expiry   INT,
    batch_number        VARCHAR(100),
    current_quantity    INT,
    expiry_date         DATE NOT NULL,
    acknowledged        BOOLEAN DEFAULT false,
    acknowledged_by     UUID REFERENCES users(id),
    acknowledged_at     TIMESTAMP WITH TIME ZONE,
    action_taken        VARCHAR(100),
        -- 'disposed', 'returned', 'discounted', 'consumed', 'ignored'
    notification_sent   BOOLEAN DEFAULT false,
    notification_sent_at TIMESTAMP WITH TIME ZONE,
    created_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW(),

    UNIQUE(batch_id, alert_level)
);

CREATE TABLE notification_preferences (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID REFERENCES users(id) ON DELETE CASCADE,
    alert_type      VARCHAR(50) NOT NULL,
        -- 'expiry_warning', 'expiry_critical', 'low_stock', 'cold_chain_excursion'
    channel         VARCHAR(20) NOT NULL DEFAULT 'in_app',
        -- 'in_app', 'email', 'sms', 'push'
    is_enabled      BOOLEAN DEFAULT true,
    threshold_days  INT DEFAULT 30,
    created_at      TIMESTAMP WITH TIME ZONE DEFAULT NOW(),

    UNIQUE(user_id, alert_type, channel)
);

-- =============================================================================
-- 22. OFFLINE QUEUE ★ Connection Resilience
-- =============================================================================

CREATE TABLE offline_queue (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    action_type         VARCHAR(50) NOT NULL,
        -- 'fefo_pick', 'adjust_stock', 'create_order', 'acknowledge_alert'
    payload             JSONB NOT NULL,
    client_id           VARCHAR(100),       -- device/session identifier
    client_timestamp    TIMESTAMP WITH TIME ZONE NOT NULL,
    status              VARCHAR(20) DEFAULT 'pending',
        -- 'pending', 'processing', 'completed', 'failed', 'conflict'
    retry_count         INT DEFAULT 0,
    max_retries         INT DEFAULT 3,
    last_error          TEXT,
    processed_at        TIMESTAMP WITH TIME ZONE,
    conflict_resolution VARCHAR(50),
        -- 'server_wins', 'client_wins', 'merge', 'manual'
    created_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- =============================================================================
-- 23. NEW VIEWS
-- =============================================================================

-- تنبيهات الصلاحية النشطة
CREATE VIEW v_active_alerts AS
SELECT
    ea.id, ea.alert_level, ea.days_until_expiry,
    ea.batch_number, ea.current_quantity, ea.expiry_date,
    ea.acknowledged, ea.action_taken,
    p.sku, p.name_ar, p.name_en, p.storage_zone,
    c.name_ar AS category_name
FROM expiry_alerts ea
JOIN products p ON ea.product_id = p.id
LEFT JOIN categories c ON p.category_id = c.id
WHERE ea.acknowledged = false
ORDER BY ea.days_until_expiry ASC;

-- المسودات المعلقة
CREATE VIEW v_pending_drafts AS
SELECT
    rd.id, rd.draft_type, rd.title, rd.status,
    rd.generated_by_ai, rd.created_at,
    u.full_name AS created_by_name,
    rd.reviewed_by, rd.review_notes
FROM report_drafts rd
LEFT JOIN users u ON rd.created_by = u.id
WHERE rd.status IN ('draft', 'under_review')
ORDER BY rd.created_at DESC;

-- طابور الاتصال المقطوع
CREATE VIEW v_offline_pending AS
SELECT
    oq.id, oq.action_type, oq.client_id,
    oq.client_timestamp, oq.status, oq.retry_count,
    oq.last_error, oq.created_at
FROM offline_queue oq
WHERE oq.status IN ('pending', 'failed')
  AND oq.retry_count < oq.max_retries
ORDER BY oq.client_timestamp ASC;

-- ملخص التدقيق (آخر 30 يوم)
CREATE VIEW v_audit_summary AS
SELECT
    DATE(created_at) AS audit_date,
    action,
    actor_type,
    COUNT(*) AS action_count,
    COUNT(DISTINCT actor_id) AS unique_actors,
    COUNT(DISTINCT entity_type) AS entity_types
FROM audit_log
WHERE created_at >= NOW() - INTERVAL '30 days'
GROUP BY DATE(created_at), action, actor_type
ORDER BY audit_date DESC, action_count DESC;

-- =============================================================================
-- 24. NEW FUNCTIONS
-- =============================================================================

-- ★ دالة إنشاء تنبيهات الصلاحية (تُستدعى دورياً)
CREATE OR REPLACE FUNCTION create_expiry_alerts()
RETURNS INT AS $$
DECLARE
    inserted_count INT := 0;
    rec RECORD;
    v_alert_level expiry_alert_level;
    days_left INT;
BEGIN
    FOR rec IN
        SELECT
            pb.id AS batch_id,
            pb.product_id,
            pb.batch_number,
            pb.current_quantity,
            pb.expiry_date,
            (pb.expiry_date - CURRENT_DATE) AS days_remaining
        FROM product_batches pb
        WHERE pb.current_quantity > 0
          AND pb.is_quarantine = false
          AND pb.is_recalled = false
          AND pb.expiry_date <= CURRENT_DATE + INTERVAL '60 days'
    LOOP
        days_left := rec.days_remaining;

        IF days_left <= 0 THEN
            v_alert_level := 'expired';
        ELSIF days_left <= 15 THEN
            v_alert_level := 'critical';
        ELSIF days_left <= 30 THEN
            v_alert_level := 'warning';
        ELSE
            v_alert_level := 'info';
        END IF;

        INSERT INTO expiry_alerts (
            product_id, batch_id, alert_level,
            days_until_expiry, batch_number,
            current_quantity, expiry_date
        ) VALUES (
            rec.product_id, rec.batch_id, v_alert_level,
            days_left, rec.batch_number,
            rec.current_quantity, rec.expiry_date
        )
        ON CONFLICT (batch_id, alert_level) DO UPDATE SET
            days_until_expiry = EXCLUDED.days_until_expiry,
            current_quantity = EXCLUDED.current_quantity,
            notification_sent = false;

        inserted_count := inserted_count + 1;
    END LOOP;

    RETURN inserted_count;
END;
$$ LANGUAGE plpgsql;

-- ★ دالة ختم التقرير رقمياً
CREATE OR REPLACE FUNCTION seal_report(
    p_report_id UUID,
    p_user_id UUID
) RETURNS JSONB AS $$
DECLARE
    report_rec RECORD;
    seal_payload TEXT;
    seal_hash VARCHAR(64);
BEGIN
    SELECT * INTO report_rec FROM reports WHERE id = p_report_id;

    IF NOT FOUND THEN
        RETURN jsonb_build_object('success', false, 'error', 'Report not found');
    END IF;

    IF report_rec.status = 'voided' THEN
        RETURN jsonb_build_object('success', false, 'error', 'Cannot seal a voided report');
    END IF;

    seal_payload := report_rec.report_number ||
                    report_rec.title ||
                    report_rec.content::TEXT ||
                    report_rec.created_at::TEXT ||
                    p_user_id::TEXT;

    seal_hash := encode(digest(seal_payload, 'sha256'), 'hex');

    UPDATE reports SET
        digital_seal = seal_hash,
        sealed_by = p_user_id,
        sealed_at = NOW(),
        status = 'sealed',
        qr_code_data = jsonb_build_object(
            'report_number', report_number,
            'hash', seal_hash,
            'verify_url', 'https://verify.lab-supply.com/' || report_number
        )::TEXT
    WHERE id = p_report_id;

    INSERT INTO report_versions (
        report_id, version_number, content, digital_seal,
        change_description, created_by
    ) VALUES (
        p_report_id, report_rec.version, report_rec.content,
        seal_hash, 'Initial seal', p_user_id
    );

    RETURN jsonb_build_object(
        'success', true,
        'report_number', report_rec.report_number,
        'digital_seal', seal_hash,
        'sealed_at', NOW()::TEXT,
        'qr_data', report_rec.qr_code_data
    );
END;
$$ LANGUAGE plpgsql;

-- ★ دالة معالجة طابور الاتصال المقطوع
CREATE OR REPLACE FUNCTION process_offline_queue(
    p_limit INT DEFAULT 10
) RETURNS TABLE (
    queue_id UUID,
    action_type VARCHAR,
    payload_out JSONB,
    client_id_out VARCHAR,
    client_ts TIMESTAMP WITH TIME ZONE
) AS $$
BEGIN
    RETURN QUERY
    UPDATE offline_queue oq SET
        status = 'processing',
        retry_count = retry_count + 1
    FROM (
        SELECT id
        FROM offline_queue
        WHERE status IN ('pending', 'failed')
          AND retry_count < max_retries
        ORDER BY client_timestamp ASC
        LIMIT p_limit
        FOR UPDATE SKIP LOCKED
    ) pending
    WHERE oq.id = pending.id
    RETURNING oq.id, oq.action_type, oq.payload, oq.client_id, oq.client_timestamp;
END;
$$ LANGUAGE plpgsql;

-- ★ دالة حساب إحصائيات FEFO (Server-Side)
CREATE OR REPLACE FUNCTION compute_fefo_stats()
RETURNS JSONB AS $$
DECLARE
    result JSONB;
    expired_cnt INT;
    critical_cnt INT;
    warning_cnt INT;
    total_batches INT;
BEGIN
    SELECT COUNT(*) INTO expired_cnt
    FROM product_batches
    WHERE current_quantity > 0 AND expiry_date <= CURRENT_DATE;

    SELECT COUNT(*) INTO critical_cnt
    FROM product_batches
    WHERE current_quantity > 0
      AND expiry_date > CURRENT_DATE
      AND expiry_date <= CURRENT_DATE + INTERVAL '15 days';

    SELECT COUNT(*) INTO warning_cnt
    FROM product_batches
    WHERE current_quantity > 0
      AND expiry_date > CURRENT_DATE + INTERVAL '15 days'
      AND expiry_date <= CURRENT_DATE + INTERVAL '30 days';

    SELECT COUNT(*) INTO total_batches
    FROM product_batches WHERE current_quantity > 0;

    result := jsonb_build_object(
        'expired_count', expired_cnt,
        'critical_count', critical_cnt,
        'warning_count', warning_cnt,
        'total_batches', total_batches,
        'compliant_count', total_batches - expired_cnt - critical_cnt - warning_cnt,
        'computed_at_server_time', NOW()::TEXT,
        'server_utc', (NOW() AT TIME ZONE 'UTC')::TEXT
    );

    RETURN result;
END;
$$ LANGUAGE plpgsql;

-- فهارس للجداول الجديدة
CREATE INDEX idx_report_drafts_status ON report_drafts(status);
CREATE INDEX idx_report_drafts_created ON report_drafts(created_at DESC);
CREATE INDEX idx_report_drafts_type ON report_drafts(draft_type);
CREATE INDEX idx_reports_number ON reports(report_number);
CREATE INDEX idx_reports_type ON reports(report_type);
CREATE INDEX idx_reports_latest ON reports(is_latest) WHERE is_latest = true;
CREATE INDEX idx_reports_draft ON reports(draft_id);
CREATE INDEX idx_report_versions_report ON report_versions(report_id, version_number DESC);
CREATE INDEX idx_expiry_alerts_level ON expiry_alerts(alert_level, acknowledged);
CREATE INDEX idx_expiry_alerts_product ON expiry_alerts(product_id);
CREATE INDEX idx_expiry_alerts_batch ON expiry_alerts(batch_id);
CREATE INDEX idx_expiry_alerts_unack ON expiry_alerts(created_at DESC)
    WHERE acknowledged = false;
CREATE INDEX idx_offline_queue_status ON offline_queue(status)
    WHERE status IN ('pending', 'failed');
CREATE INDEX idx_notification_prefs_user ON notification_preferences(user_id);

-- =============================================================================
-- END OF SCHEMA
-- =============================================================================
