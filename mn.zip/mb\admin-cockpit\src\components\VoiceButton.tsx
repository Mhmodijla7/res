/**
 * VoiceButton.tsx — زر التسجيل الصوتي مع معالجة النوايا الغامضة
 * 
 * ★ التدفق:
 * 1. المستخدم يضغط ويسجل
 * 2. Whisper يحوّل الصوت لنص
 * 3. Intent Classifier يصنّف النية
 * 4. إذا كانت غامضة → يعرض Draft Action للموافقة
 * 5. إذا كانت واضحة → يرسل مباشرة
 */

'use client';

import React, { useState, useRef, useCallback, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Mic, MicOff, Loader2, AlertTriangle, CheckCircle } from 'lucide-react';

interface VoiceButtonProps {
  onTranscript: (text: string, isAmbiguous: boolean) => void;
  onError?: (error: string) => void;
  language?: string;
  className?: string;
}

type RecordingState = 'idle' | 'recording' | 'processing' | 'error';

export function VoiceButton({
  onTranscript,
  onError,
  language = 'ar-SA',
  className = '',
}: VoiceButtonProps) {
  const [state, setState] = useState<RecordingState>('idle');
  const [error, setError] = useState<string | null>(null);
  const [amplitude, setAmplitude] = useState<number[]>([]);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const animFrameRef = useRef<number>(0);

  // كلمات تدل على الغموض
  const AMBIGUOUS_MARKERS = [
    'إذا', 'لو', 'ان شاء', 'ربما', 'يمكن', 'بالتأكيد',
    'ما أدري', 'مو متأكد', 'تقريباً', 'يعني',
  ];

  const isAmbiguous = useCallback((text: string): boolean => {
    const lower = text.toLowerCase();
    return AMBIGUOUS_MARKERS.some(marker => lower.includes(marker));
  }, []);

  // مراقبة الامplitude للتأثير البصري
  const monitorAmplitude = useCallback(() => {
    if (!analyserRef.current) return;
    const dataArray = new Uint8Array(analyserRef.current.frequencyBinCount);
    analyserRef.current.getByteFrequencyData(dataArray);

    // أخذ 12 عينة
    const samples: number[] = [];
    const step = Math.floor(dataArray.length / 12);
    for (let i = 0; i < 12; i++) {
      samples.push(dataArray[i * step] / 255);
    }
    setAmplitude(samples);

    if (state === 'recording') {
      animFrameRef.current = requestAnimationFrame(monitorAmplitude);
    }
  }, [state]);

  const startRecording = useCallback(async () => {
    setError(null);

    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
          sampleRate: 16000,
        }
      });

      // إعداد AudioContext للامplitude
      const audioContext = new AudioContext();
      const source = audioContext.createMediaStreamSource(stream);
      const analyser = audioContext.createAnalyser();
      analyser.fftSize = 256;
      source.connect(analyser);
      analyserRef.current = analyser;

      // إعداد MediaRecorder
      const mimeType = MediaRecorder.isTypeSupported('audio/webm;codecs=opus')
        ? 'audio/webm;codecs=opus'
        : 'audio/webm';

      const recorder = new MediaRecorder(stream, { mimeType });
      chunksRef.current = [];

      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunksRef.current.push(e.data);
      };

      recorder.onstop = async () => {
        setState('processing');
        stream.getTracks().forEach(t => t.stop());
        audioContext.close();

        const audioBlob = new Blob(chunksRef.current, { type: mimeType });

        try {
          const formData = new FormData();
          formData.append('audio', audioBlob, 'voice.webm');
          formData.append('language', language === 'ar-SA' ? 'ar' : language);

          const response = await fetch('/api/speech/transcribe', {
            method: 'POST',
            body: formData,
          });

          if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
          }

          const data = await response.json();

          if (data.error) {
            throw new Error(data.error);
          }

          const text: string = data.text?.trim() || '';
          if (!text) {
            throw new Error('لم يتم التعرف على أي كلام');
          }

          const ambiguous = isAmbiguous(text);
          onTranscript(text, ambiguous);
          setState('idle');
        } catch (err: any) {
          const msg = err.message || 'خطأ في معالجة الصوت';
          setError(msg);
          setState('error');
          onError?.(msg);
          setTimeout(() => setState('idle'), 3000);
        }
      };

      mediaRecorderRef.current = recorder;
      recorder.start(100); // كل 100ms
      setState('recording');

      // بدء مراقبة الامplitude
      animFrameRef.current = requestAnimationFrame(monitorAmplitude);
    } catch (err: any) {
      const msg = err.name === 'NotAllowedError'
        ? 'يرجى السماح بالوصول للميكروفون'
        : `خطأ في الميكروفون: ${err.message}`;
      setError(msg);
      setState('error');
      onError?.(msg);
      setTimeout(() => setState('idle'), 3000);
    }
  }, [language, isAmbiguous, onTranscript, onError, monitorAmplitude]);

  const stopRecording = useCallback(() => {
    if (mediaRecorderRef.current?.state === 'recording') {
      mediaRecorderRef.current.stop();
    }
    cancelAnimationFrame(animFrameRef.current);
  }, []);

  const handleClick = useCallback(() => {
    if (state === 'recording') {
      stopRecording();
    } else if (state === 'idle' || state === 'error') {
      startRecording();
    }
  }, [state, startRecording, stopRecording]);

  // تنظيف
  useEffect(() => {
    return () => {
      cancelAnimationFrame(animFrameRef.current);
      mediaRecorderRef.current?.stop();
    };
  }, []);

  const buttonStyles: Record<RecordingState, string> = {
    idle: 'bg-gray-100 text-gray-600 hover:bg-indigo-100 hover:text-indigo-600',
    recording: 'bg-red-500 text-white shadow-lg shadow-red-200/50',
    processing: 'bg-indigo-100 text-indigo-600',
    error: 'bg-red-100 text-red-600',
  };

  const icons: Record<RecordingState, React.ReactNode> = {
    idle: <Mic size={22} />,
    recording: <MicOff size={22} />,
    processing: <Loader2 size={22} className="animate-spin" />,
    error: <AlertTriangle size={22} />,
  };

  return (
    <div className={`relative ${className}`}>
      {/* الأمواج الصوتية */}
      <AnimatePresence>
        {state === 'recording' && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            className="absolute inset-0 flex items-center justify-center pointer-events-none"
          >
            <div className="flex items-end gap-[2px] h-8">
              {amplitude.map((amp, i) => (
                <motion.div
                  key={i}
                  className="w-[3px] rounded-full bg-red-400"
                  animate={{ height: Math.max(4, amp * 32) }}
                  transition={{ type: 'spring', stiffness: 500, damping: 20 }}
                />
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* الزر الرئيسي */}
      <motion.button
        whileTap={{ scale: 0.9 }}
        animate={state === 'recording' ? { scale: [1, 1.05, 1] } : {}}
        transition={state === 'recording' ? { repeat: Infinity, duration: 1.5 } : {}}
        onClick={handleClick}
        disabled={state === 'processing'}
        className={`
          relative z-10 p-4 rounded-full transition-all duration-300
          ${buttonStyles[state]}
          disabled:opacity-50 disabled:cursor-not-allowed
        `}
        title={state === 'recording' ? 'انقر للإيقاف' : 'اضغط للتسجيل الصوتي'}
      >
        {icons[state]}
      </motion.button>

      {/* رسالة الخطأ */}
      <AnimatePresence>
        {error && state === 'error' && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="absolute top-full mt-2 left-1/2 -translate-x-1/2 whitespace-nowrap bg-red-50 text-red-600 text-xs px-3 py-1.5 rounded-lg border border-red-200 shadow-sm"
          >
            {error}
          </motion.div>
        )}
      </AnimatePresence>

      {/* مؤشر الحالة */}
      {state === 'processing' && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="absolute top-full mt-2 left-1/2 -translate-x-1/2 whitespace-nowrap text-xs text-indigo-500"
        >
          جاري التعرف على الصوت...
        </motion.div>
      )}
    </div>
  );
}

export default VoiceButton;
